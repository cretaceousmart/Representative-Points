function f = Random_Gamma(n)
f = gamrnd(9,0.5,n,1);
end0
