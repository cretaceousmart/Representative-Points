function f = Newton (fun,dfun,x0,delta)
    X1=x0-fun(x0)/dfun(x0); 
    while abs(fun(X1))>=delta
       x0 = X1;
       X1 = x0-fun(x0)/dfun(x0);
    end
    f = X1;
    
end
