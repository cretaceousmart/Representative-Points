%ע��H0�ֲ��ı�ʱ��pi������Ҫ�޸�
%%
function f = Original_Chi_Method(random_variable,n,k,x_square,m)
%Calculate the mi and pi
    chi_pi = 1/(2*k):1/(2*k):1;
    chi_RP = icdf('Normal',chi_pi(1:2*k-1),0,1);
    chi_mi = zeros(2*k,1);
    
    %for mi
    %�����
    for  h = 1:n 
       if random_variable(h)<chi_RP(1)
           chi_mi(1) = chi_mi(1)+1;
       end
    end
    %���ұ�
    for  h = 1:n 
       if random_variable(h)>chi_RP(2*k-1)
           chi_mi(2*k) = chi_mi(2*k)+1;
       end
    end      
    %�м䲿��
    for j = 1:(2*k-2)
       for h = 1:n
           if random_variable(h)>=chi_RP(j)&&random_variable(h)<=chi_RP(j+1)
               chi_mi(j+1) = chi_mi(j+1)+1;
           end
       end
    end
    
    
    %Calculate the statistic
    chi_x_square = 0;
    pi = 1/(2*k);
    for i = 1:2*k
        chi_x_square = chi_x_square+((chi_mi(i)-n*pi)^2)/(n*pi); 
    end

    %Comparison
%     x_square = chi2inv(1-alpha,k-3);
    if chi_x_square>=x_square %Reject H0
%         f = 1;
          f = [1,x_square,chi_x_square,(1-chi2cdf(chi_x_square,m-3))];
    else
%         f = 0;
          f = [0,x_square,chi_x_square,(1-chi2cdf(chi_x_square,m-3))];
    end


end