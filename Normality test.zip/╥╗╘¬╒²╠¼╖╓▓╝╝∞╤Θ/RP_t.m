%%
%Even case:
%Step1 Initializaing
clc;clear;
format long
L = 5; 
y_mse = zeros(L,L); %Set y_mse is a L x L matrix
y_mse(1,1) =  0.8646852977;%Set inital value as 0.8646852977(From the paper)
epsilon = 10e-6;
delta = 10e-4;
error = 1;%Set intial value of error is 1
df = 10;n = df;

LP = 0;RP = y_mse(1,1);
counter = 0;
y_mse(1,2) = 1/(2+1)*y_mse(1,1);
%Step2 First we need to find the x(1,2)
while error>=epsilon
    %Step2.1 Use Newton's method to solve x2
    x1 = y_mse(1,2);
    x0 = y_mse(1,2)+1.5; % Maybe it's not reasonable
%     fun = @(x2) tpdf(0,df)+ x1*tcdf(0,df)-tpdf(0.5*(x1+x2),df)-x1*tcdf(0.5*(x1+x2),df);
%     dfun = @(x2) 0.25*(n+1)*(x1+x2)*(n+0.25*(x1+x2)^2)^(-1)*tpdf(0.5*(x1+x2),df)-0.5*x1*tpdf(0.5*(x1+x2),df);
    
    fun= @(x2) G(0,n)-G((x1+x2)/2,n)-x1*(tcdf((x1+x2)/2,n)-tcdf(0,n));
    dfun= @(x2) (x2-x1)/4*tpdf((x1+x2)/2,n);
    
    y_mse(2,2) = Newton(fun,dfun,x0,delta);
      
    %Step2.2. Use Newton's method to solve another x2
    x0 = y_mse(1,2)+1.5; % Maybe it's not reasonable
%     fun = @(XL) tpdf(0.5*(y_mse(1,2)+XL),df)-XL*(1-tcdf(0.5*(y_mse(1,2)+XL),df));
%     dfun = @(XL) -0.25*(n+1)*(y_mse(1,2)+XL)*(n+0.25*(y_mse(1,2)+XL)^2)^(-1)*tpdf(0.5*(y_mse(1,2)+XL),df)-1+tcdf(0.5*(y_mse(1,2)+XL),df)+0.5*XL*tpdf(0.5*(y_mse(1,2)+XL),df);
    fun=@(XL) G((y_mse(1,2)+XL)/2,n)-XL+XL*tcdf((y_mse(1,2)+XL)/2,n);
    dfun=@(XL) (XL-y_mse(1,2))/4*tpdf(0.5*(XL+y_mse(1,2)),n)+tcdf(0.5*(XL+y_mse(1,2)),n)-1;
    new_xL = Newton(fun,dfun,x0,delta);

    
    %Step2.3. Compare these two x2 and Adjust the x1
    error = abs(y_mse(2,2)-new_xL);
    if y_mse(2,2)<(new_xL+epsilon)
        LP = y_mse(1,2); y_mse(1,2) = 0.5*(LP+RP);
    elseif y_mse(2,2)>(new_xL-epsilon)
        RP = y_mse(1,2); y_mse(1,2) = 0.5*(LP+RP);
    end
    counter = counter+1;
end



%Step3. Use Newton's method to solve other points
for j = 3:L
   LP = 0;RP = y_mse(1,j-1);
   error = 1;
   y_mse(1,j) = y_mse(1,j-1)/(j+1); %Change the initial point
   counter = 0;
   while error>=epsilon
       
   %Step3.1 Use Newton's method to solve x(L,2)
    x1 = y_mse(1,j); %ÿ�е�һ��
    x0 = y_mse(1,j)+1.5; % Maybe it's not reasonable
%     fun = @(x2) tpdf(0,df)+ x1*tcdf(0,df)-tpdf(0.5*(x1+x2),df)-x1*tcdf(0.5*(x1+x2),df);
%     dfun = @(x2) 0.25*(n+1)*(x1+x2)*(n+0.25*(x1+x2)^2)^(-1)*tpdf(0.5*(x1+x2),df)-0.5*x1*tpdf(0.5*(x1+x2),df);
    fun= @(x2) G(0,n)-G((x1+x2)/2,n)-x1*(tcdf((x1+x2)/2,n)-tcdf(0,n));
    dfun= @(x2) (x2-x1)/4*tpdf((x1+x2)/2,n);
    
    y_mse(2,j) = Newton(fun,dfun,x0,delta);  %ÿ�еڶ���      
   
    %Step3.2 Use Newton's method to solve x(L,3) TO x(L,L)   
    for i = 3:j
        x0 = y_mse(i-1,j)+1.5; % Maybe it's not reasonable
%         fun = @(xL)tpdf(0.5*(y_mse(i-2,j)+y_mse(i-1,j)),df)-tpdf(0.5*(y_mse(i-1,j)+xL),df)-y_mse(i-1,j)*((tcdf(0.5*(y_mse(i-1,j)+xL),df)-tcdf(0.5*(y_mse(i-1,j)+y_mse(i-2,j)),df)));
%         dfun =@(xL) 0.25*(n+1)*(y_mse(i-1,j)+xL)*(n+0.25*(y_mse(i-1,j)+xL)^2)^(-1)*tpdf(0.5*(y_mse(i-1,j)+xL),df)-0.5*y_mse(i-1,j)*tpdf(0.5*(y_mse(i-1,j)+xL),df);         
        fun=@(xL) G((y_mse(i-2,j)+y_mse(i-1,j))/2,n)-G((y_mse(i-1,j)+xL)/2,n)-y_mse(i-1,j)*(tcdf((y_mse(i-1,j)+xL)/2,n)-tcdf((y_mse(i-2,j)+y_mse(i-1,j))/2,n));
        dfun=@(xL) (xL-y_mse(i-1,j))/4*tpdf((y_mse(i-1,j)+xL)/2,n);
        xL = Newton(fun,dfun,x0,delta);
        y_mse(i,j) = xL;
    end
    

    %Step3.3 Use Newton's method to solve another x(L,L)
    x0 = y_mse(j,j)+1.5; %Maybe it's not reasonable
%     fun = @(XL) tpdf(0.5*(y_mse(j-1,j)+XL),df)-XL*(1-tcdf(0.5*(y_mse(j-1,j)+XL),df));
%     dfun = @(XL) -0.25*(n+1)*(y_mse(j-1,j)+XL)*(n+0.25*(y_mse(j-1,j)+XL)^2)^(-1)*tpdf(0.5*(y_mse(j-1,j)+XL),df)-1+tcdf(0.5*(y_mse(j-1,j)+XL),df)+0.5*XL*tpdf(0.5*(y_mse(j-1,j)+XL),df);
    fun=@(XL) G((y_mse(j-1,j)+XL)/2,n)-XL+XL*tcdf((y_mse(j-1,j)+XL)/2,n);
    dfun=@(XL) (XL-y_mse(j-1,j))/4*tpdf(0.5*(XL+y_mse(j-1,j)),n)+tcdf(0.5*(XL+y_mse(j-1,j)),n)-1;
    
    
    new_xL = Newton(fun,dfun,x0,delta);
    %Step3.4. Compare these two xl and Adjust the x1
    error = abs(y_mse(j,j)-new_xL);
    if y_mse(j,j)<(new_xL+epsilon)
        LP = y_mse(1,j); y_mse(1,j) = 0.5*(LP+RP);
    elseif y_mse(j,j)>(new_xL-epsilon)
        RP = y_mse(1,j); y_mse(1,j) = 0.5*(LP+RP);
    end
    counter = counter+1;
   end
   

end
%%