clc;clear;
n = 50:50:500;
N = 1000; %�������
% n = [10,15,20,25,30,40,50,100,200,300,400,500,1000,1500,2000];
size = length(n);

%1.Represent Point
    %1.1 N(0,1)
normal_RP_data = xlsread('C:\ѧϰ\FYP\Code\һԪ��̬�ֲ�����\Normal.xlsx',1);

    %1.2 t(n-1) n = 30:30:300
% t_RP_m10 =  xlsread('C:\ѧϰ\FYP\��һƪ����\Simulation\t_RP_m10.xlsx',1);
% t_RP_m20 =  xlsread('C:\ѧϰ\FYP\Code\һԪ��̬�ֲ�����\t_RP_m20.xlsx',1);
t_RP_m30 =  xlsread('C:\ѧϰ\FYP\��һƪ����\Simulation\t_RP_m30.xlsx',1);
    

result_m10 = zeros(4,size);
result_m20 = zeros(4,size);
result_m30 = zeros(4,size);

% x_square_m10 = [0.016;0.03;0.012;0.017];
% x_square_m20 = [0.016;0.03;0.01;0.03];
% x_square_m30 = [0.016;0.03;0.01;0.02];


    
% for i = 1:size
%     result_m10(:,i) = Main(n(i),5,N,normal_RP_data,t_RP_m10(:,i),x_square_m10 ); % m = 10
%     
%     result_m20(:,i) = Main(n(i),10,N,normal_RP_data,t_RP_m20(:,i),x_square_m20 );% m = 20
%     
%     result_m30(:,i) = Main(n(i),15,N,normal_RP_data,t_RP_m30(:,i),x_square_m30 );% m = 30
% end
% for i = 1:size
%     result_m10(:,i) = Main(n(i),5,N,normal_RP_data,t_RP_m10(:,i)); % m = 10
%     
%     result_m20(:,i) = Main(n(i),10,N,normal_RP_data,t_RP_m20(:,i) );% m = 20
%     
%     result_m30(:,i) = Main(n(i),15,N,normal_RP_data,t_RP_m30(:,i) );% m = 30
% end

for i = 1:size
    result_m10(:,i) = Main(n(i),5,N,normal_RP_data,t_RP_m10(:,i)); % m = 10
    
    result_m20(:,i) = Main(n(i),10,N,normal_RP_data,t_RP_m20(:,i) );% m = 20
    
    result_m30(:,i) = Main(n(i),15,N,normal_RP_data,t_RP_m30(:,i) );% m = 30
end
% total_result = [result_m10(1:4,:);result_m20(1:4,:);result_m30(1:4,:)];
total_result = [result_m10;result_m20;result_m30];
%Matlab to Excel
%xlswrite('C:\ѧϰ\FYP\��һƪ����\Simulation\Shift Weibull .xlsx',total_result)

% %Plot
% 
% subplot(131)
% for i = 1:6
%    plot(n,result_m10(i,:),'.-')
%    hold on 
% end
%  set(gca,'xtick',30:30:300);
% 
% hl = legend('MSE-RP Chi-square Method_1','MSE-RP Chi-square Method_2','MSE-RP Chi-square Method_3','Original Chi-square Method','KS Method','SW Method');
% % hl = legend('MSE-RP Chi-square Method_1','MSE-RP Chi-square Method_2','MSE-RP Chi-square Method_3','Original Chi-square Method');
% set(hl,'Box','off','Location','southeast')
% title('Weibull(3,2) m = 10')
% xlabel('sample size')
% ylabel('Power')
% 
% 
% subplot(132)
% for i = 1:6
%    plot(n,result_m20(i,:),'.-')
%    hold on 
% end
% set(gca,'xtick',30:30:300);
% hl = legend('MSE-RP Chi-square Method_1','MSE-RP Chi-square Method_2','MSE-RP Chi-square Method_3','Original Chi-square Method','KS Method','SW Method');
% % hl = legend('MSE-RP Chi-square Method_1','MSE-RP Chi-square Method_2','MSE-RP Chi-square Method_3','Original Chi-square Method');
% set(hl,'Box','off','Location','southeast')
% title('Weibull(3,2) m = 20')
% xlabel('sample size')
% ylabel('Power')
% 
% subplot(133)
% for i = 1:6
%    plot(n,result_m30(i,:),'.-')
%    hold on 
% end
% set(gca,'xtick',30:30:300);
% hl = legend('MSE-RP Chi-square Method_1','MSE-RP Chi-square Method_2','MSE-RP Chi-square Method_3','Original Chi-square Method','KS Method','SW Method');
% % hl = legend('MSE-RP Chi-square Method_1','MSE-RP Chi-square Method_2','MSE-RP Chi-square Method_3','Original Chi-square Method');
% set(hl,'Box','off','Location','southeast')
% title('Weibull(3,2) m = 30')
% xlabel('sample size')
% ylabel('Power')



data = total_result;
plot(n,data(1,:),'.-','Color','g','LineWidth',1.5)
axis([50 500 0 1])
hold on 
plot(n,data(2,:),'Marker','+','Color','b')
hold on 
plot(n,data(3,:),'Marker','x')
hold on 
plot(n,data(4,:),'.-','LineWidth',1.5,'Color','r')
hold on 
set(gca,'xtick',50:50:500);
% set(gca,'ytick',0:0.1:1);
hl = legend('MSE-RP Chi-square Method_1','MSE-RP Chi-square Method_2','MSE-RP Chi-square Method_3','Original Chi-square Method');
set(hl,'Box','off','Location','southeast')
title('Shift Weibull      m = 30')
xlabel('sample size')
ylabel('Power')


%=========================
clc;clear;
n = 50:50:500;
N = 3000; %�������
size = length(n);


normal_RP_data = xlsread('C:\ѧϰ\FYP\Code\һԪ��̬�ֲ�����\Normal.xlsx',1);

t_RP_m10 =  xlsread('C:\ѧϰ\FYP\��һƪ����\Simulation\t_RP_m10.xlsx',1);
t_RP_m20 =  xlsread('C:\ѧϰ\FYP\��һƪ����\Simulation\t_RP_m20.xlsx',1);
t_RP_m30 =  xlsread('C:\ѧϰ\FYP\��һƪ����\Simulation\t_RP_m30.xlsx',1);
    

result_m10 = zeros(4,size);
result_m20 = zeros(4,size);
result_m30 = zeros(4,size);
for i = 1:size
    result_m10(:,i) = Main(n(i),5,N,normal_RP_data,t_RP_m10(:,i)); % m = 10
    
    result_m20(:,i) = Main(n(i),10,N,normal_RP_data,t_RP_m20(:,i) );% m = 20
    
    result_m30(:,i) = Main(n(i),15,N,normal_RP_data,t_RP_m30(:,i) );% m = 30
end

total_result = [result_m10;result_m20;result_m30];
xlswrite('C:\ѧϰ\FYP\��һƪ����\Simulation\kotz2.xlsx',total_result)


%===========================================================================
%For Shift Chisquare and Shift Weibull
clc;clear;
n  = 50:50:500;
N = 5000; %�������
size = length(n);


normal_RP_data = xlsread('C:\ѧϰ\FYP\Code\һԪ��̬�ֲ�����\Normal.xlsx',1);

t_RP_m10 =  xlsread('C:\ѧϰ\FYP\��һƪ����\Simulation\t_RP_m10.xlsx',1);
t_RP_m20 =  xlsread('C:\ѧϰ\FYP\��һƪ����\Simulation\t_RP_m20.xlsx',1);
t_RP_m30 =  xlsread('C:\ѧϰ\FYP\��һƪ����\Simulation\t_RP_m30.xlsx',1);

result_m10 = zeros(4,size);
result_m20 = zeros(4,size);
result_m30 = zeros(4,size);
for i = 1:size
    result_m10(:,i) = Main(n(i),5,N,normal_RP_data,t_RP_m10(:,i)); % m = 10
    
    result_m20(:,i) = Main(n(i),10,N,normal_RP_data,t_RP_m20(:,i) );% m = 20
    
    result_m30(:,i) = Main(n(i),15,N,normal_RP_data,t_RP_m30(:,i) );% m = 30
end

total_result = [result_m10;result_m20;result_m30];
xlswrite('C:\ѧϰ\FYP\��һƪ����\Simulation\shift weibull.xlsx',total_result)














% 



% m10_data = total_result(1:4,:);
% data = m10_data;
% plot(n,data(1,:),'.-','Color','g','LineWidth',1.5)
% axis([50 500 0 1])
% hold on 
% plot(n,data(2,:),'Marker','+','Color','b')
% hold on 
% plot(n,data(3,:),'Marker','x')
% hold on 
% plot(n,data(4,:),'.-','LineWidth',1.5,'Color','r')
% hold on 
% set(gca,'xtick',50:50:500);
% % set(gca,'ytick',0:0.1:1);
% hl = legend('MSE-RP Chi-square Method_1','MSE-RP Chi-square Method_2','MSE-RP Chi-square Method_3','Original Chi-square Method');
% set(hl,'Box','off','Location','southeast')
% title('Shift Weibull      m = 30')
% xlabel('sample size')
% ylabel('Power')















%=========================================================================
%ʵ��Ӧ��
iris_data = iris;
Setosa_data = iris_data(101:150,2:5);
hist(Setosa_x4,10)

Versicolor_data = iris_data(56:100,2:5);
Virginica_data = iris_data(101:150,2:5);

subplot(141)
hist(Setosa_data(:,1),6)
subplot(142)
hist(Setosa_data(:,2),6)
subplot(143)
hist(Setosa_data(:,3),6)
subplot(144)
hist(Setosa_data(:,4),6)


example(Setosa_data(:,1),15)
example(Setosa_data(:,2),15)
example(Setosa_data(:,3),15)
example(Setosa_data(:,4),15)







subplot(131)
hist(Setosa_data(:,1),10,'Color','r')
hold on 
subplot(132)
hist(Versicolor_data(:,1),10,'Color','b')
hold on
subplot(133)
hist(Virginica_data(:,1),10,'Color','g')

subplot(131)
hist(Setosa_data(:,2),10,'Color','r')
hold on 
subplot(132)
hist(Versicolor_data(:,2),10,'Color','b')
hold on
subplot(133)
hist(Virginica_data(:,2),10,'Color','g')


subplot(131)
hist(Setosa_data(:,3),10,'Color','r')
hold on 
subplot(132)
hist(Versicolor_data(:,3),10,'Color','b')
hold on
subplot(133)
hist(Virginica_data(:,3),10,'Color','g')


subplot(131)
hist(Setosa_data(:,4),10,'Color','r')
hold on 
subplot(132)
hist(Versicolor_data(:,4),10,'Color','b')
hold on
subplot(133)
hist(Virginica_data(:,4),10,'Color','g')

%=============================================================================================
%%
%New simulation: Compare with SW,KS , first type of Ha
clc;clear;
n  = 50:50:500;
N = 5000; %�������
size = length(n);


normal_RP_data = xlsread('C:\ѧϰ\FYP\Code\һԪ��̬�ֲ�����\Normal.xlsx',1);

t_RP_m10 =  xlsread('C:\ѧϰ\FYP\��һƪ����\Simulation\t_RP_m10.xlsx',1);
t_RP_m20 =  xlsread('C:\ѧϰ\FYP\��һƪ����\Simulation\t_RP_m20.xlsx',1);
t_RP_m30 =  xlsread('C:\ѧϰ\FYP\��һƪ����\Simulation\t_RP_m30.xlsx',1);

result_m10 = zeros(4,size);
result_m20 = zeros(4,size);
result_m30 = zeros(4,size);
for i = 1:size
    result_m10(:,i) = Main(n(i),5,N,normal_RP_data,t_RP_m10(:,i)); % m = 10
    
    result_m20(:,i) = Main(n(i),10,N,normal_RP_data,t_RP_m20(:,i) );% m = 20
    
    result_m30(:,i) = Main(n(i),15,N,normal_RP_data,t_RP_m30(:,i) );% m = 30
end

total_result = [result_m10;result_m20;result_m30];
xlswrite('C:\ѧϰ\FYP\��һƪ����\Simulation\SWKS\Cauchy.xlsx',total_result)

%��ͼ

t_data = xlsread('C:\ѧϰ\FYP\��һƪ����\Simulation\SWKS\t(5).xlsx',1);
la_data = xlsread('C:\ѧϰ\FYP\��һƪ����\Simulation\SWKS\Laplace(0,1).xlsx',1);
de_data = xlsread('C:\ѧϰ\FYP\��һƪ����\Simulation\SWKS\Cauchy.xlsx',1);


n = 100:100:1000;
subplot(331)
m10_data = t_data(1:4,:);
data = m10_data;
plot(n,data(1,:),'.-','Color','g','LineWidth',1.5)
axis([100 1000 0 1])
hold on 
plot(n,data(2,:),'Marker','+','Color','b')
hold on 
plot(n,data(3,:),'Marker','x')
hold on 
plot(n,data(4,:),'.-','LineWidth',1.5,'Color','r')
hold on 
set(gca,'xtick',100:100:1000);
% set(gca,'ytick',0:0.1:1);
hl = legend('MSE-RP x^2','x^2','KS','SW');
set(hl,'Box','off','Location','southeast')
title('t(5)  m = 10')
xlabel('sample size')
ylabel('Power')

subplot(332)
m10_data = t_data(5:8,:);
data = m10_data;
plot(n,data(1,:),'.-','Color','g','LineWidth',1.5)
axis([100 1000 0 1])
hold on 
plot(n,data(2,:),'Marker','+','Color','b')
hold on 
plot(n,data(3,:),'Marker','x')
hold on 
plot(n,data(4,:),'.-','LineWidth',1.5,'Color','r')
hold on 
set(gca,'xtick',100:100:1000);
% set(gca,'ytick',0:0.1:1);
hl = legend('MSE-RP x^2','x^2','KS','SW');
set(hl,'Box','off','Location','southeast')
title('t(5)  m = 20')
xlabel('sample size')
ylabel('Power')

subplot(333)
m10_data = t_data(9:12,:);
data = m10_data;
plot(n,data(1,:),'.-','Color','g','LineWidth',1.5)
axis([100 1000 0 1])
hold on 
plot(n,data(2,:),'Marker','+','Color','b')
hold on 
plot(n,data(3,:),'Marker','x')
hold on 
plot(n,data(4,:),'.-','LineWidth',1.5,'Color','r')
hold on 
set(gca,'xtick',100:100:1000);
% set(gca,'ytick',0:0.1:1);
hl = legend('MSE-RP x^2','x^2','KS','SW');
set(hl,'Box','off','Location','southeast')
title('t(5)  m = 30')
xlabel('sample size')
ylabel('Power')

%===

n = 50:50:500;
subplot(334)
m10_data = la_data(1:4,:);
data = m10_data;
plot(n,data(1,:),'.-','Color','g','LineWidth',1.5)
axis([50 500 0 1])
hold on 
plot(n,data(2,:),'Marker','+','Color','b')
hold on 
plot(n,data(3,:),'Marker','x')
hold on 
plot(n,data(4,:),'.-','LineWidth',1.5,'Color','r')
hold on 
set(gca,'xtick',50:50:500);
% set(gca,'ytick',0:0.1:1);
hl = legend('MSE-RP x^2','x^2','KS','SW');
set(hl,'Box','off','Location','southeast')
title('Lapalce m = 10')
xlabel('sample size')
ylabel('Power')

subplot(335)
m10_data = la_data(5:8,:);
data = m10_data;
plot(n,data(1,:),'.-','Color','g','LineWidth',1.5)
axis([50 500 0 1])
hold on 
plot(n,data(2,:),'Marker','+','Color','b')
hold on 
plot(n,data(3,:),'Marker','x')
hold on 
plot(n,data(4,:),'.-','LineWidth',1.5,'Color','r')
hold on 
set(gca,'xtick',50:50:500);
% set(gca,'ytick',0:0.1:1);
hl = legend('MSE-RP x^2','x^2','KS','SW');
set(hl,'Box','off','Location','southeast')
title('Lapalce m = 20')
xlabel('sample size')
ylabel('Power')

subplot(336)
m10_data = la_data(9:12,:);
data = m10_data;
plot(n,data(1,:),'.-','Color','g','LineWidth',1.5)
axis([50 500 0 1])
hold on 
plot(n,data(2,:),'Marker','+','Color','b')
hold on 
plot(n,data(3,:),'Marker','x')
hold on 
plot(n,data(4,:),'.-','LineWidth',1.5,'Color','r')
hold on 
set(gca,'xtick',50:50:500);
% set(gca,'ytick',0:0.1:1);
hl = legend('MSE-RP x^2','x^2','KS','SW');
set(hl,'Box','off','Location','southeast')
title('Lapalce m = 30')
xlabel('sample size')
ylabel('Power')
%======

subplot(337)
m10_data = de_data(1:4,:);
data = m10_data;
plot(n,data(1,:),'.-','Color','g','LineWidth',1.5)
axis([50 500 0 1])
hold on 
plot(n,data(2,:),'Marker','+','Color','b')
hold on 
plot(n,data(3,:),'Marker','x')
hold on 
plot(n,data(4,:),'.-','LineWidth',1.5,'Color','r')
hold on 
set(gca,'xtick',50:50:500);
% set(gca,'ytick',0:0.1:1);
hl = legend('MSE-RP x^2','x^2','KS','SW');
set(hl,'Box','off','Location','southeast')
title('Cauchy m = 10')
xlabel('sample size')
ylabel('Power')

subplot(338)
m10_data = de_data(5:8,:);
data = m10_data;
plot(n,data(1,:),'.-','Color','g','LineWidth',1.5)
axis([50 500 0 1])
hold on 
plot(n,data(2,:),'Marker','+','Color','b')
hold on 
plot(n,data(3,:),'Marker','x')
hold on 
plot(n,data(4,:),'.-','LineWidth',1.5,'Color','r')
hold on 
set(gca,'xtick',50:50:500);
% set(gca,'ytick',0:0.1:1);
hl = legend('MSE-RP x^2','x^2','KS','SW');
set(hl,'Box','off','Location','southeast')
title('Cauchy m = 20')
xlabel('sample size')
ylabel('Power')

subplot(339)
m10_data = de_data(9:12,:);
data = m10_data;
plot(n,data(1,:),'.-','Color','g','LineWidth',1.5)
axis([50 500 0 1])
hold on 
plot(n,data(2,:),'Marker','+','Color','b')
hold on 
plot(n,data(3,:),'Marker','x')
hold on 
plot(n,data(4,:),'.-','LineWidth',1.5,'Color','r')
hold on 
set(gca,'xtick',50:50:500);
% set(gca,'ytick',0:0.1:1);
hl = legend('MSE-RP x^2','x^2','KS','SW');
set(hl,'Box','off','Location','southeast')
title('Cauchy m = 30')
xlabel('sample size')
ylabel('Power')
































