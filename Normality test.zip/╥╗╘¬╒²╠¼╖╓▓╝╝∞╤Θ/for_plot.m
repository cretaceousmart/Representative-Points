%%
%You may need to adjust the file path
t_data = xlsread('D:\ѧϰ\FYP\��һƪ����\Simulation\t(5).xlsx',1);
la_data = xlsread('D:\ѧϰ\FYP\��һƪ����\Simulation\Laplace(0,1).xlsx',1);
de_data = xlsread('D:\ѧϰ\FYP\��һƪ����\Simulation\cauchy.xlsx',1);

n = 100:100:1000;
subplot(331)

m10_data = t_data(1:4,:);
data = m10_data;
plot(n,data(1,:),'.-','Color','g','LineWidth',1.5)
axis([100 1000 0 1])
hold on 
plot(n,data(2,:),'Marker','+','Color','b')
hold on 
plot(n,data(3,:),'Marker','x')
hold on 
plot(n,data(4,:),'.-','LineWidth',1.5,'Color','r')
hold on 

% set(gca,'ytick',0:0.1:1);
hl = legend('RP-x^2(1)','RP-x^2(2)','RP-x^2(3)','PF-x^2');
set(hl,'Box','off','Location','southeast')
title('t(5)  m = 6')
xlabel('sample size')
ylabel('Power')

subplot(332)
m10_data = t_data(5:8,:);
data = m10_data;
plot(n,data(1,:),'.-','Color','g','LineWidth',1.5)
axis([100 1000 0 1])
hold on 
plot(n,data(2,:),'Marker','+','Color','b')
hold on 
plot(n,data(3,:),'Marker','x')
hold on 
plot(n,data(4,:),'.-','LineWidth',1.5,'Color','r')
hold on 

% set(gca,'ytick',0:0.1:1);
hl = legend('RP-x^2(1)','RP-x^2(2)','RP-x^2(3)','PF-x^2');
set(hl,'Box','off','Location','southeast')
title('t(5)  m = 8')
xlabel('sample size')
ylabel('Power')

subplot(333)
m10_data = t_data(9:12,:);
data = m10_data;
plot(n,data(1,:),'.-','Color','g','LineWidth',1.5)
axis([100 1000 0 1])
hold on 
plot(n,data(2,:),'Marker','+','Color','b')
hold on 
plot(n,data(3,:),'Marker','x')
hold on 
plot(n,data(4,:),'.-','LineWidth',1.5,'Color','r')
hold on 

% set(gca,'ytick',0:0.1:1);
hl = legend('RP-x^2(1)','RP-x^2(2)','RP-x^2(3)','PF-x^2');
set(hl,'Box','off','Location','southeast')
title('t(5)  m = 10')
xlabel('sample size')
ylabel('Power')

%===

n = 50:50:500;
subplot(334)
m10_data = la_data(1:4,:);
data = m10_data;
plot(n,data(1,:),'.-','Color','g','LineWidth',1.5)
axis([50 500 0 1])
hold on 
plot(n,data(2,:),'Marker','+','Color','b')
hold on 
plot(n,data(3,:),'Marker','x')
hold on 
plot(n,data(4,:),'.-','LineWidth',1.5,'Color','r')
hold on 

% set(gca,'ytick',0:0.1:1);
hl = legend('RP-x^2(1)','RP-x^2(2)','RP-x^2(3)','PF-x^2');
set(hl,'Box','off','Location','southeast')
title('Laplace(0,1) m = 6')
xlabel('sample size')
ylabel('Power')

subplot(335)
m10_data = la_data(5:8,:);
data = m10_data;
plot(n,data(1,:),'.-','Color','g','LineWidth',1.5)
axis([50 500 0 1])
hold on 
plot(n,data(2,:),'Marker','+','Color','b')
hold on 
plot(n,data(3,:),'Marker','x')
hold on 
plot(n,data(4,:),'.-','LineWidth',1.5,'Color','r')
hold on 

% set(gca,'ytick',0:0.1:1);
hl = legend('RP-x^2(1)','RP-x^2(2)','RP-x^2(3)','PF-x^2');
set(hl,'Box','off','Location','southeast')
title('Laplace(0,1) m = 8')
xlabel('sample size')
ylabel('Power')

subplot(336)
m10_data = la_data(9:12,:);
data = m10_data;
plot(n,data(1,:),'.-','Color','g','LineWidth',1.5)
axis([50 500 0 1])
hold on 
plot(n,data(2,:),'Marker','+','Color','b')
hold on 
plot(n,data(3,:),'Marker','x')
hold on 
plot(n,data(4,:),'.-','LineWidth',1.5,'Color','r')
hold on 

% set(gca,'ytick',0:0.1:1);
hl = legend('RP-x^2(1)','RP-x^2(2)','RP-x^2(3)','PF-x^2');
set(hl,'Box','off','Location','southeast')
title('Laplace(0,1) m = 10')
xlabel('sample size')
ylabel('Power')
%======

subplot(337)
m10_data = de_data(1:4,:);
data = m10_data;
plot(n,data(1,:),'.-','Color','g','LineWidth',1.5)
axis([50 500 0 1])
hold on 
plot(n,data(2,:),'Marker','+','Color','b')
hold on 
plot(n,data(3,:),'Marker','x')
hold on 
plot(n,data(4,:),'.-','LineWidth',1.5,'Color','r')

% set(gca,'ytick',0:0.1:1);
hl = legend('RP-x^2(1)','RP-x^2(2)','RP-x^2(3)','PF-x^2');
set(hl,'Box','off','Location','southeast')
title('Cauchy m = 6')
xlabel('sample size')
ylabel('Power')

subplot(338)
m10_data = de_data(5:8,:);
data = m10_data;
plot(n,data(1,:),'.-','Color','g','LineWidth',1.5)
axis([50 500 0 1])
hold on 
plot(n,data(2,:),'Marker','+','Color','b')
hold on 
plot(n,data(3,:),'Marker','x')
hold on 
plot(n,data(4,:),'.-','LineWidth',1.5,'Color','r')
hold on 

% set(gca,'ytick',0:0.1:1);
hl = legend('RP-x^2(1)','RP-x^2(2)','RP-x^2(3)','PF-x^2');
set(hl,'Box','off','Location','southeast')
title('Cauchy m = 8')
xlabel('sample size')
ylabel('Power')

subplot(339)
m10_data = de_data(9:12,:);
data = m10_data;
plot(n,data(1,:),'.-','Color','g','LineWidth',1.5)
axis([50 500 0 1])
hold on 
plot(n,data(2,:),'Marker','+','Color','b')
hold on 
plot(n,data(3,:),'Marker','x')
hold on 
plot(n,data(4,:),'.-','LineWidth',1.5,'Color','r')
hold on 

% set(gca,'ytick',0:0.1:1);
hl = legend('RP-x^2(1)','RP-x^2(2)','RP-x^2(3)','PF-x^2');
set(hl,'Box','off','Location','southeast')
title('Cauchy m = 10')
xlabel('sample size')
ylabel('Power')
%%