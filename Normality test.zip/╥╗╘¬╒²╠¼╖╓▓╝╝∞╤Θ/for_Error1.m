clc;clear;
N = 5000;
alpha = 0.05;
n = 1000;
k = 10;
x_square = chi2inv(1-alpha,22-3);
% mse_cv = 39.1;
% original_cv = 32.1;

i = 1;
RP = [  -2.908048448754711
  -2.278740562126883
  -1.856993430290831
  -1.523424409004684
  -1.238473294710464
  -0.983645523688712
  -0.748535505618182
  -0.526489635613606
  -0.312792206971519
  -0.103764415992068
                   0
   0.103764415992068
   0.312792206971519
   0.526489635613606
   0.748535505618182
   0.983645523688712
   1.238473294710464
   1.523424409004684
   1.856993430290831
   2.278740562126883
   2.908048448754711];
I_1 = zeros(N,1);
I_2 = zeros(N,1);
I_3 = zeros(N,1);
I_4 = zeros(N,1);
I_5 = zeros(N,1);

while i<=N
    random_number = random('Normal',0,1,n,1);
    miu = mean(random_number);
    sigma = sum((random_number-miu).^2)/n;
    random_number = (random_number-miu)/sqrt(sigma);
   I_1(i) = MSE_Chi_Method(random_number,RP,n,k,alpha,x_square);%MSE-RP Chi-square test
   I_2(i) = Original_Chi_Method(random_number,n,k,alpha,x_square);%Original Chi-square test
   I_3(i) = kstest(random_number,'Alpha',0.38);%ks test
   I_4(i) = swtest(random_number,0.04);%sw test
%    I_5(i) = chi2gof(random_number,'Alpha',0.05,'NBins',22);

    i = i+1; 
end
MSE_Chi_Error_1 = sum(I_1)/N
Original_Chi_Error_1 = sum(I_2)/N
KS_Error_1 = sum(I_3)/N
SW_Error_1 = sum(I_4)/N
% Matlab_Chi_Error1 = sum(I_5)/N
















