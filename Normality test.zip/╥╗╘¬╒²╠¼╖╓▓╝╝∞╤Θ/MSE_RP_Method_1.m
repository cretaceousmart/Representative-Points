
%ע��H0�ֲ��ı�ʱ��pi������Ҫ�޸�
%%
function f = MSE_RP_Method_1(random_variable,RP,n,k,x_square,m)
%Calculate the mi and pi
    mi = zeros(2*k,1);
    pi = zeros(2*k,1);
    BP = zeros(k-1,1);
    for i = 1:k-1
       BP(i) = 0.5*(RP(i)+RP(i+1)); 
    end
    a = zeros(k-1,1);
    for i = 1:k-1
        a(i) = -BP(k-i);
    end
    BP = [a;0;BP];
    
    
    %for mi
    %�����
    h = 1;
    while h<=n
       if random_variable(h)<BP(1)
           mi(1) = mi(1)+1;
       end
        h = h+1;
    end
    
    %���ұ�
    h = 1;
    while h<=n
       if random_variable(h)>BP(2*k-1)
           mi(2*k) = mi(2*k)+1;
       end    
        h = h+1;
    end
    
    %�м䲿��
    j = 1;
    while j <=(2*k-2)
        h = 1;
        while h<=n
           if random_variable(h)>=BP(j)&&random_variable(h)<=BP(j+1)
               mi(j+1) = mi(j+1)+1;
           end
           h = h+1; 
        end
       
        j = j+1;
    end
    
 

    %for pi
    pi(1) = normcdf(BP(1));pi(k) = normcdf(0)-normcdf(BP(k-1));
    
    i = 2;
    while i<=k-1
       pi(i) = normcdf(BP(i))- normcdf(BP(i-1));
       i = i+1;
    end
    
    a = pi;   
    i = 1;
    while i<=k
        pi(k+i) = a(k-i+1); 
        i = i+1;
    end
    
    %Step5.Calculate the statistic
    mse_x_square = 0;
    for i = 1:2*k
       mse_x_square = mse_x_square+((mi(i)-n*pi(i))^2)/(n*pi(i)); 
    end
    
    %Step6.Comparison
%     x_square = chi2inv(1-alpha,k-3);
    if mse_x_square>=x_square %Reject H0
%         f = 1;
          f = [1,x_square,mse_x_square,(1-chi2cdf(mse_x_square,m-3))];    
    else
%         f = 0;
          f = [0,x_square,mse_x_square,(1-chi2cdf(mse_x_square,m-3))];
    end

end