
%%
%You just need to focus on this part of the code!!!
%Leave the other code in this file along!!!

clc;clear;
%parameter
n = [10,15,20,25,30,40,50,100,200,300,400,500,1000,1500,2000]; 
k = 10; %how many part you need to devide
size = length(n);

%critical number
x_square = chi2inv(0.95,2*k-3);


%For each n,
result_1 = zeros(size,1);result_2 = zeros(size,1);result_3 = zeros(size,1);result_4 = zeros(size,1);
for i = 1:size
    result = main_normal(n(i),k,1000,x_square);
    result_1(i) = result(1);result_2(i) = result(2);result_3(i) = result(3);result_4(i) = result(4);
end
final_result = [result_1,result_2,result_3,result_4];

%Matlab to Excel
xlswrite('C:\ѧϰ\FYP\Code\һԪ��̬�ֲ�����\ģ����\�޸�Alpha\�ǶԳƷֲ�\Beta\Beta(3,3).xlsx',final_result)


%%









%ȫ��
biaoti = {'Random sample of Beta(3,3)'};
subplot(221)
plot(n,result_1,'.-')
set(gca,'xtick',0:100:1500);
hold on
plot(n,result_2,'.-')
hold on
plot(n,result_3,'.-')
hold on
plot(n,result_4,'.-')
hold on
hl = legend('MSE-RP Chi-square Method','Original Chi-square Method','KS Method','SW Method');
set(hl,'Box','off','Location','East')
title(biaoti)
xlabel('sample size')
ylabel('Power')
% ylabel('Type I Error')
%10-100
subplot(222)
plot(n(1:8),result_1(1:8),'.-')
set(gca,'xtick',10:10:100);
hold on
plot(n(1:8),result_2(1:8),'.-')
hold on
plot(n(1:8),result_3(1:8),'.-')
hold on
plot(n(1:8),result_4(1:8),'.-')
hold on
hl = legend('MSE-RP Chi-square Method','Original Chi-square Method','KS Method','SW Method');
set(hl,'Box','off','Location','East')
title(biaoti)
xlabel('sample size')
ylabel('Power')
% ylabel('Type I Error')
%100-500
subplot(223)
plot(n(8:12),result_1(8:12),'.-')
set(gca,'xtick',100:100:500);
hold on
plot(n(8:12),result_2(8:12),'.-')
hold on
plot(n(8:12),result_3(8:12),'.-')
hold on
plot(n(8:12),result_4(8:12),'.-')
hold on
hl = legend('MSE-RP Chi-square Method','Original Chi-square Method','KS Method','SW Method');
set(hl,'Box','off','Location','East')
title(biaoti)
xlabel('sample size')
ylabel('Power')
% ylabel('Type I Error')
%500-2000
subplot(224)
plot(n(12:15),result_1(12:15),'.-')
set(gca,'xtick',500:500:2000);
hold on
plot(n(12:15),result_2(12:15),'.-')
hold on
plot(n(12:15),result_3(12:15),'.-')
hold on
plot(n(12:15),result_4(12:15),'.-')
hold on
hl = legend('MSE-RP Chi-square Method','Original Chi-square Method','KS Method','SW Method');
set(hl,'Box','off','Location','East')
title(biaoti)
xlabel('sample size')
ylabel('Power')
% ylabel('Type I Error')


%ʵ�飨Verson 2��

% ʵ��1���ı�H1�Ĳ�ͬ�ֲ�

%Type1 : Symmetric Short-tail Distribution

%Type2 : Symmetric Long-tail Distribution

%Type3 : Asymmetric Distribution






















t_data = xlsread('D:\ѧϰ\FYP\��һƪ����\Simulation\t(5).xlsx',1);
la_data = xlsread('D:\ѧϰ\FYP\��һƪ����\Simulation\Laplace(0,1).xlsx',1);
de_data = xlsread('D:\ѧϰ\FYP\��һƪ����\Simulation\cauchy.xlsx',1);

n = 100:100:1000;
subplot(331)

m10_data = t_data(1:4,:);
data = m10_data;
plot(n,data(1,:),'.-','Color','g','LineWidth',1.5)
axis([100 1000 0 1])
hold on 
plot(n,data(2,:),'Marker','+','Color','b')
hold on 
plot(n,data(3,:),'Marker','x')
hold on 
plot(n,data(4,:),'.-','LineWidth',1.5,'Color','r')
hold on 

% set(gca,'ytick',0:0.1:1);
hl = legend('RP-x^2(1)','RP-x^2(2)','RP-x^2(3)','PF-x^2');
set(hl,'Box','off','Location','southeast')
title('t(5)  m = 6')
xlabel('sample size')
ylabel('Power')

subplot(332)
m10_data = t_data(5:8,:);
data = m10_data;
plot(n,data(1,:),'.-','Color','g','LineWidth',1.5)
axis([100 1000 0 1])
hold on 
plot(n,data(2,:),'Marker','+','Color','b')
hold on 
plot(n,data(3,:),'Marker','x')
hold on 
plot(n,data(4,:),'.-','LineWidth',1.5,'Color','r')
hold on 

% set(gca,'ytick',0:0.1:1);
hl = legend('RP-x^2(1)','RP-x^2(2)','RP-x^2(3)','PF-x^2');
set(hl,'Box','off','Location','southeast')
title('t(5)  m = 8')
xlabel('sample size')
ylabel('Power')

subplot(333)
m10_data = t_data(9:12,:);
data = m10_data;
plot(n,data(1,:),'.-','Color','g','LineWidth',1.5)
axis([100 1000 0 1])
hold on 
plot(n,data(2,:),'Marker','+','Color','b')
hold on 
plot(n,data(3,:),'Marker','x')
hold on 
plot(n,data(4,:),'.-','LineWidth',1.5,'Color','r')
hold on 

% set(gca,'ytick',0:0.1:1);
hl = legend('RP-x^2(1)','RP-x^2(2)','RP-x^2(3)','PF-x^2');
set(hl,'Box','off','Location','southeast')
title('t(5)  m = 10')
xlabel('sample size')
ylabel('Power')

%===

n = 50:50:500;
subplot(334)
m10_data = la_data(1:4,:);
data = m10_data;
plot(n,data(1,:),'.-','Color','g','LineWidth',1.5)
axis([50 500 0 1])
hold on 
plot(n,data(2,:),'Marker','+','Color','b')
hold on 
plot(n,data(3,:),'Marker','x')
hold on 
plot(n,data(4,:),'.-','LineWidth',1.5,'Color','r')
hold on 

% set(gca,'ytick',0:0.1:1);
hl = legend('RP-x^2(1)','RP-x^2(2)','RP-x^2(3)','PF-x^2');
set(hl,'Box','off','Location','southeast')
title('Laplace(0,1) m = 6')
xlabel('sample size')
ylabel('Power')

subplot(335)
m10_data = la_data(5:8,:);
data = m10_data;
plot(n,data(1,:),'.-','Color','g','LineWidth',1.5)
axis([50 500 0 1])
hold on 
plot(n,data(2,:),'Marker','+','Color','b')
hold on 
plot(n,data(3,:),'Marker','x')
hold on 
plot(n,data(4,:),'.-','LineWidth',1.5,'Color','r')
hold on 

% set(gca,'ytick',0:0.1:1);
hl = legend('RP-x^2(1)','RP-x^2(2)','RP-x^2(3)','PF-x^2');
set(hl,'Box','off','Location','southeast')
title('Laplace(0,1) m = 8')
xlabel('sample size')
ylabel('Power')

subplot(336)
m10_data = la_data(9:12,:);
data = m10_data;
plot(n,data(1,:),'.-','Color','g','LineWidth',1.5)
axis([50 500 0 1])
hold on 
plot(n,data(2,:),'Marker','+','Color','b')
hold on 
plot(n,data(3,:),'Marker','x')
hold on 
plot(n,data(4,:),'.-','LineWidth',1.5,'Color','r')
hold on 

% set(gca,'ytick',0:0.1:1);
hl = legend('RP-x^2(1)','RP-x^2(2)','RP-x^2(3)','PF-x^2');
set(hl,'Box','off','Location','southeast')
title('Laplace(0,1) m = 10')
xlabel('sample size')
ylabel('Power')
%======

subplot(337)
m10_data = de_data(1:4,:);
data = m10_data;
plot(n,data(1,:),'.-','Color','g','LineWidth',1.5)
axis([50 500 0 1])
hold on 
plot(n,data(2,:),'Marker','+','Color','b')
hold on 
plot(n,data(3,:),'Marker','x')
hold on 
plot(n,data(4,:),'.-','LineWidth',1.5,'Color','r')

% set(gca,'ytick',0:0.1:1);
hl = legend('RP-x^2(1)','RP-x^2(2)','RP-x^2(3)','PF-x^2');
set(hl,'Box','off','Location','southeast')
title('Cauchy m = 6')
xlabel('sample size')
ylabel('Power')

subplot(338)
m10_data = de_data(5:8,:);
data = m10_data;
plot(n,data(1,:),'.-','Color','g','LineWidth',1.5)
axis([50 500 0 1])
hold on 
plot(n,data(2,:),'Marker','+','Color','b')
hold on 
plot(n,data(3,:),'Marker','x')
hold on 
plot(n,data(4,:),'.-','LineWidth',1.5,'Color','r')
hold on 

% set(gca,'ytick',0:0.1:1);
hl = legend('RP-x^2(1)','RP-x^2(2)','RP-x^2(3)','PF-x^2');
set(hl,'Box','off','Location','southeast')
title('Cauchy m = 8')
xlabel('sample size')
ylabel('Power')

subplot(339)
m10_data = de_data(9:12,:);
data = m10_data;
plot(n,data(1,:),'.-','Color','g','LineWidth',1.5)
axis([50 500 0 1])
hold on 
plot(n,data(2,:),'Marker','+','Color','b')
hold on 
plot(n,data(3,:),'Marker','x')
hold on 
plot(n,data(4,:),'.-','LineWidth',1.5,'Color','r')
hold on 

% set(gca,'ytick',0:0.1:1);
hl = legend('RP-x^2(1)','RP-x^2(2)','RP-x^2(3)','PF-x^2');
set(hl,'Box','off','Location','southeast')
title('Cauchy m = 10')
xlabel('sample size')
ylabel('Power')















%==========================================================================
%ʵ��(Verson 1)
%1.Gamma�ֲ���������ͬʱ�仯
% result_1 = zeros(20,20);
% result_2 = zeros(20,20);
% for i = 21:50
%    for j  = 0.1:0.1:2
%        result = main_normal (100,10,1000,0.05,i,j);
%        result_1(i,floor(10*j)) = result(1);
%        result_2(i,floor(10*j)) = result(2);
%    end
% end

%2.ֻ�仯��һ������
% result_1 = zeros(100,1);
% result_2 = zeros(100,1);
% for i = 1:100
%    result =  main_normal (100,10,10000,0.05,i,0.5);
%    result_1(i) = result(1);
%    result_2(i) = result(2);
% end

%3.n�����仯
% result_1 = zeros(1,1);
% result_2 = zeros(1,1);
% for i = 1:10:1000
%     result = main_normal (i,10,10000,0.05,20,0.5);
%     result_1 = [result_1,result(1)];
%     result_2 = [result_2,result(2)];
% end


%4.k�����仯���������ȡ10��
% result_1 = zeros(1,1);
% result_2 = zeros(1,1);
% for i = 1:10
%     result = main_normal (100,i,10000,0.05,20,0.5);
%     result_1 = [result_1,result(1)];
%     result_2 = [result_2,result(2)];
% end



% mesh(result_1)
% hold on 
% mesh(result_2)
% mesh(result_1-result_2)
% 
% plot(mean(result_1-result_2,2))


%�ֲ�ͼ
% for i = 30:50
%     pd = makedist('Gamma',i,0.5);
%     x = 0:0.01:30;
%     pdf_gamma = pdf(pd,x);
%     plot(x,pdf_gamma,'LineWidth',2)
%     hold on
% end

%�����̫
% clear
% clc
% pd_1 = makedist('Normal','mu',-2.5,'sigma',2);
% pd_2 = makedist('Normal','mu',1.5,'sigma',2);
% x = -10:0.1:10;
% pdf_1 = pdf(pd_1,x);
% pdf_2 = pdf(pd_2,x);
% pdf = 0.4*pdf_1+0.6*pdf_2
% plot(x,pdf,'LineWidth',2)
%==========================================================================
clear;clc
format long
alpha = 0.05;
k = 5;
m = 2*k;
RP_data = xlsread('.\Normal.xlsx',1);
normal_RP = RP_data(m,1:m/2);
% random_number = [62,66,78,79,80,84,84,85,85,86,86,87,88,88,89,89,91,91,91,91,92,92,92,92,93,94,94,94,95,95,95,96,96,96,96,96,97,97,97,97,97,97,98,98,98,98,98,98,98,99,99,99,99,99,100,100,100,100,100,101,101,101,101,102,102,102,102,102,102,102,103, 103,103,103,104,104,104,104,104,104,105,105,106,107,107,109,110,111,111,111,114,115,117,122,132,132,137,137,138]';
% random_number = [5.5,5.55,5.57,5.34,5.42,5.3,5.61,5.36,5.53,5.79,5.47,5.75,4.88,5.29,5.62,5.10,5.63,5.68,5.07,5.58,5.29,5.27,5.34,5.85,5.26,5.65,5.44,5.39,5.46]
random_number = [850,960,880,890,74,0,940,880,810,840,900,960,880,810,780,1070,940,860,820,810,930,880,720,800,760,850,800,720,770,810,950,850,620,760,790,980,880,860,740,810,980,900,9+70,750,820,880,840,950,760,850,1000,830,880,910,870,980,790,9+10,920,800,960,760,840,850,800,960,760,840,850,810,960,800,840,780,870]
n = length(random_number);
miu = mean(random_number);
sigma = std(random_number);
% b = sum(abs(random_number-miu))/n;
RP = miu+sigma.*normal_RP; 
x_square = chi2inv(1-alpha,m-3);

f1 = MSE_RP_Method_1(random_number,RP,n,k,x_square,m)
f2 = Original_Chi_Method(random_number,n,k,x_square,m)





























