%ע��H0�ֲ��ı�ʱ��pi������Ҫ�޸�
%%
function f = MSE_Chi_Method(random_variable,RP,n,k,alpha,x_square)
%Calculate the mi and pi
    mi = zeros(2*k+2,1);
    pi = zeros(2*k+2,1);
    
    %for mi
    %�����
%     for  h = 1:n 
%        if random_variable(h)<RP(1)
%            mi(1) = mi(1)+1;
%        end
%     end
    
    h = 1;
    while h<=n
       if random_variable(h)<RP(1)
           mi(1) = mi(1)+1;
       end
        h = h+1;
    end
    
    %���ұ�
%     for  h = 1:n 
%        if random_variable(h)>RP(2*k+1)
%            mi(2*k+2) = mi(2*k+2)+1;
%        end
%     end         
    h = 1;
    while h<=n
       if random_variable(h)>RP(2*k+1)
           mi(2*k+2) = mi(2*k+2)+1;
       end    
        h = h+1;
    end
    
    %�м䲿��
%     for j = 1:(2*k)
%        for h = 1:n
%            if random_variable(h)>=RP(j)&&random_variable(h)<=RP(j+1)
%                mi(j+1) = mi(j+1)+1;
%            end
%        end
%     end
    
    j = 1;
    while j <=(2*k)
        h = 1;
        while h<=n
           if random_variable(h)>=RP(j)&&random_variable(h)<=RP(j+1)
               mi(j+1) = mi(j+1)+1;
           end
           h = h+1; 
        end
       
        j = j+1;
    end
    
    
    

    %for pi
    pi = zeros(k+1,1);
    pi(1) = normcdf(RP(1));pi(k+1) = normcdf(0)-normcdf(RP(k));
%     for i = 2:k
%        pi(i) = normcdf(RP(i))- normcdf(RP(i-1));
%     end
    
    i = 2;
    while i<=k
       pi(i) = normcdf(RP(i))- normcdf(RP(i-1));
       i = i+1;
    end
    
    a = pi;
%     for i = 1:k+1
%        pi(k+1+i) = a(k+1-i+1); 
%     end
    
    i = 1;
    while i<=k+1
        pi(k+1+i) = a(k+1-i+1); 
        i = i+1;
    end
    
    %Step5.Calculate the statistic
    mse_x_square = 0;
    for i = 1:2*k+2
       mse_x_square = mse_x_square+((mi(i)-n*pi(i))^2)/(n*pi(i)); 
    end
    
    %Step6.Comparison
%     x_square = chi2inv(1-alpha,k-3);
    if mse_x_square>=x_square %Reject H0
        f = 1;
    else
        f = 0;
    end

end