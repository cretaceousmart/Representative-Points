function [weibull,Prob] = W_RP_matlab(m, shape_para, scale_para, tol_err,max_iter)
%%tol_err=10e-12,max_iter=10000
a = 1+(0:m-1)./(m-1);
J = zeros(m,m);
g = zeros(1,m);

made_changes = true;
iterations = 0;
converged = true;
while (made_changes==true && (iterations < max_iter))
    iterations = iterations + 1;
    made_changes = false;
    
    J(1,1) = wblcdf((a(1)+a(2))/2,scale_para,shape_para) - wblpdf((a(1)+a(2))/2,scale_para,shape_para)*(a(2)-a(1))/4;
    J(m,m) = 1 - wblcdf((a(m-1)+a(m))/2,scale_para,shape_para) - wblpdf((a(m-1)+a(m))/2,scale_para,shape_para)*(a(m)-a(m-1))/4;
    
    for k = 2:(m-1)
        J(k,k)=wblcdf((a(k)+a(k+1))/2,scale_para,shape_para)-wblcdf((a(k-1)+a(k))/2,scale_para,shape_para)-wblpdf((a(k-1)+a(k))/2,scale_para,shape_para)*(a(k)-a(k-1))/4-wblpdf((a(k)+a(k+1))/2,scale_para,shape_para)*(a(k+1)-a(k))/4;
    end
    
    for k = 1:(m-1)
      J(k+1,k) = -wblpdf((a(k)+a(k+1))/2,scale_para,shape_para)*(a(k+1)-a(k))/4;
      J(k,k+1) = -wblpdf((a(k)+a(k+1))/2,scale_para,shape_para)*(a(k+1)-a(k))/4;
    end
    
    g(1) = a(1)*(wblcdf((a(1)+a(2))/2,scale_para,shape_para))-Int(0,(a(1)+a(2))/2,shape_para,scale_para);%%%Int�����������ܻ����ô���
    g(m) = a(m)*(1-wblcdf((a(m-1)+a(m))/2,scale_para,shape_para))-Int((a(m-1)+a(m))/2,Inf,shape_para,scale_para);
    
    for k = 2:(m-1)
      g(k) = a(k)*(wblcdf((a(k)+a(k+1))/2,scale_para,shape_para)-wblcdf((a(k-1)+a(k))/2,scale_para,shape_para))-Int((a(k-1)+a(k))/2,(a(k)+a(k+1))/2,shape_para,scale_para);
    end
    
    newa = a - g/J;%inv
    newa = sort(newa);
    made_changes = max(abs(g)) > tol_err;
    a = newa;
end

    if made_changes==true
        print('Newton method terminated before convergence');
    end
  
  a_1 = a(1:(m-1));
  a_2 = a(2:m);
  aa = (a_1+a_2)/2;
  pp = wblcdf(aa,scale_para,shape_para);
  p = [pp(1),diff(pp),1-pp(m-1)];
  %%weibull_RPs = list[RPs=a, Prob=p, teminals=aa,iterations=iterations,converged~=made_changes)];
  weibull=a;   
  Prob=p ;
  teminals=aa;
  iterations=iterations;
  converged~=made_changes;
end

