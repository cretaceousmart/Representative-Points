%Traditional Chi-square Test
clc;clear;
N = 10000;
result = zeros(N,1);
counter = 1;
k = 10;
alpha = 0.05;

chi_pi = 1/22:1/22:1;
chi_RP = icdf('Normal',chi_pi(1:21),0,1);

while counter<=N
    n = 30;
    %Step1.Generate random number of H1
    random_number = gamrnd(9,0.5,n,1);%���ڿ��Ե���������ֵ����Ч��α仯
    %Step2.Calculate the mean and variance
    miu = mean(random_number);
    sigma = sum((random_number-miu).^2)/n;
    %Step3.Standralized
    random_variable = (random_number-miu)/sqrt(sigma);
    %Other Steps:
    chi_mi = zeros(2*k+2,1);

for  h = 1:n %�����
       if random_variable(h)<=chi_RP(1)
           chi_mi(1) = chi_mi(1)+1;
       end
end
    
    for  h = 1:n %���ұ�
       if random_variable(h)>chi_RP(2*k+1)
           chi_mi(2*k+1) = chi_mi(2*k+1)+1;
       end
    end      
    %�м䲿��
    for j = 1:(2*k-1)
       for h = 1:n
           if random_variable(h)>=chi_RP(j)&&random_variable(h)<=chi_RP(j+1)
               chi_mi(j) = chi_mi(j)+1;
           end
       end
    end
    
chi_x_square = 0;
for i = 1:22
    chi_x_square = chi_x_square+((chi_mi(i)-n*chi_pi(i))^2)/(n*chi_pi(i)); 
end
    
x_square = chi2inv(1-alpha,k-3);
if chi_x_square>=x_square %Reject H0
    result(counter) = 1;
end

    counter = counter+1;
end

power = sum(result)/N;

