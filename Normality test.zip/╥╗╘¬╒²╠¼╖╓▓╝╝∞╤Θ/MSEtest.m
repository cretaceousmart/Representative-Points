%%\
clc;clear;
format long
k = 10;
%����ʹ��20��������
%%
L = k;
y_mse_1 = zeros(L,L); %Set y_mse is a L x L matrix
y_mse_1(1,1) = 0.797885;%Set inital value as 0.797(From the paper)
epsilon = 10e-5;
delta = 10e-8;
error = 1;%Set intial value of error is 1
LP = 0;RP = y_mse_1(1,1);
counter = 0;
y_mse_1(1,2) = 1/(2+1)*y_mse_1(1,1);
%Step2 First we need to find the x2 
while error>=epsilon
    %Step2.1 Use Newton's method to solve x2
    x1 = y_mse_1(1,2);
    x0 = y_mse_1(1,2)+1; % Maybe it's not reasonable
    fun = @(x2) normpdf(0)+ x1*normcdf(0)-normpdf(0.5*(x1+x2))-x1*normcdf(0.5*(x1+x2));
    dfun = @(x2) (x1+x2)/(4*sqrt(2*pi))*exp(-1/8*(x1+x2)^2)-0.5*x1*normpdf(0.5*(x1+x2));
    y_mse_1(2,2) = Newton(fun,dfun,x0,delta);
      
    %Step2.2. Use Newton's method to solve another x2
    x0 = y_mse_1(1,2)+1; % Maybe it's not reasonable
    fun = @(XL) normpdf(0.5*(y_mse_1(1,2)+XL))-XL*(1-normcdf(0.5*(y_mse_1(1,2)+XL)));
    dfun = @(XL) -0.25*(y_mse_1(1,2)+XL)*(1/sqrt(2*pi))*exp(-1/8*(y_mse_1(1,2)+XL)^2)+0.5*XL*normpdf(0.5*(y_mse_1(1,2)+XL))-1;
    new_xL = Newton(fun,dfun,x0,delta);
    %Step2.3. Compare these two x2 and Adjust the x1
    error = abs(y_mse_1(2,2)-new_xL);
    if y_mse_1(2,2)<(new_xL+epsilon)
        LP = y_mse_1(1,2); y_mse_1(1,2) = 0.5*(LP+RP);
    elseif y_mse_1(2,2)>(new_xL-epsilon)
        RP = y_mse_1(1,2); y_mse_1(1,2) = 0.5*(LP+RP);
    end
    counter = counter+1;
end

%Step3. Use Newton's method to solve x3 to xL
for j = 3:L
   LP = 0;RP = y_mse_1(1,j-1);
   error = 1;
   y_mse_1(1,j) = y_mse_1(1,j-1)/(j+1); %Change the initial point
   counter = 0;
   while error>=epsilon
       
   %Step3.1 Use Newton's method to solve x(L,2)
    x1 = y_mse_1(1,j);
    x0 = y_mse_1(1,j)+1; % Maybe it's not reasonable
    fun = @(x2) normpdf(0)+ x1*normcdf(0)-normpdf(0.5*(x1+x2))-x1*normcdf(0.5*(x1+x2));
    dfun = @(x2) (x1+x2)/(4*sqrt(2*pi))*exp(-1/8*(x1+x2)^2)-0.5*x1*normpdf(0.5*(x1+x2));
    y_mse_1(2,j) = Newton(fun,dfun,x0,delta);        
   
    %Step3.2 Use Newton's method to solve x(L,3) TO x(L,L)   
    for i = 3:j
        x0 = y_mse_1(i-1,j)+1; % Maybe it's not reasonable
        fun = @(xL)normpdf(0.5*(y_mse_1(i-2,j)+y_mse_1(i-1,j)))-normpdf(0.5*(y_mse_1(i-1,j)+xL))-y_mse_1(i-1,j)*((normcdf(0.5*(y_mse_1(i-1,j)+xL))-normcdf(0.5*(y_mse_1(i-1,j)+y_mse_1(i-2,j)))));
        dfun =@(xL) 0.25*(y_mse_1(i-1,j)+xL)*(exp(-1/8*(y_mse_1(i-1,j)+xL)^2))/(sqrt(2*pi))-0.5*y_mse_1(i-1,j)*normpdf(0.5*(y_mse_1(i-1,j)+xL));
        xL = Newton(fun,dfun,x0,delta);
        y_mse_1(i,j) = xL;
    end
    %Step3.3 Use Newton's method to solve another x(L,L)
    x0 = y_mse_1(j,j)+1; %Maybe it's not reasonable
    fun = @(XL) normpdf(0.5*(y_mse_1(j-1,j)+XL))-XL*(1-normcdf(0.5*(y_mse_1(j-1,j)+XL)));
    dfun = @(XL) -0.25*(y_mse_1(j-1,j)+XL)*(1/sqrt(2*pi))*exp(-1/8*(y_mse_1(j-1,j)+XL)^2)+0.5*XL*normpdf(0.5*(y_mse_1(j-1,j)+XL))-1;
    new_xL = Newton(fun,dfun,x0,delta);
    %Step3.4. Compare these two xl and Adjust the x1
    error = abs(y_mse_1(j,j)-new_xL);
    if y_mse_1(j,j)<(new_xL+epsilon)
        LP = y_mse_1(1,j); y_mse_1(1,j) = 0.5*(LP+RP);
    elseif y_mse_1(j,j)>(new_xL-epsilon)
        RP = y_mse_1(1,j); y_mse_1(1,j) = 0.5*(LP+RP);
    end
    counter = counter+1;
   end
   

end

RP = zeros(k,1);
for i = 1:k
   RP(i) = -y_mse_1(k+1-i,L) ;
end
RP = [RP;y_mse_1(:,L)];




%%
%Main Programme of MSE RP Chi-square test
N = 10000;
result = zeros(N,1);
I = zeros(N,1);
counter = 1;
k = 10;
alpha = 0.05;
while counter<=N
    n = 100;%��������
    %Step1.Generate random number of H1
    random_number = gamrnd(9,0.5,n,1);%���ڿ��Ե���������ֵ����Ч��α仯
    %Step2.Calculate the mean and variance
    miu = mean(random_number);
    sigma = sum((random_number-miu).^2)/n;
    %Step3.Standralized
    random_variable = (random_number-miu)/sqrt(sigma);
    %Step4.Calculate the mi and pi
    mi = zeros(2*k+2,1);
    pi = zeros(2*k+2,1);
    
    %for mi
    for  h = 1:n %�����
       if random_variable(h)<=RP(1)
           mi(1) = mi(1)+1;
       end
    end
    
    for  h = 1:n %���ұ�
       if random_variable(h)>RP(2*k)
           mi(2*k+1) = mi(2*k+1)+1;
       end
    end      
    %�м䲿��
    for j = 1:(2*k-1)
       for h = 1:n
           if random_variable(h)>=RP(j)&&random_variable(h)<=RP(j+1)
               mi(j) = mi(j)+1;
           end
       end
    end
    %for pi
    pi = zeros(k+1,1);
    pi(1) = normcdf(RP(1));pi(k+1) = normcdf(0)-normcdf(RP(k));
    for i = 2:k
       pi(i) = normcdf(RP(i))- normcdf(RP(i-1));
    end
    a = pi;
    for i = 1:k+1
       pi(k+1+i) = a(k+1-i+1); 
    end
    
    %Step5.Calculate the statistic
    mse_x_square = 0;
    for i = 1:21
       mse_x_square = mse_x_square+((mi(i)-n*pi(i))^2)/(n*pi(i)); 
    end
    
    %Step6.Comparison
    x_square = chi2inv(1-alpha,k-3);
    if mse_x_square>=x_square %Reject H0
        result(counter) = 1;
    end
 
counter = counter+1;
end

power = sum(result)/N;






%%














