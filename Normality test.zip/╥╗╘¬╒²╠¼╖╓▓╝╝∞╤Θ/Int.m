function result = Int(lo,up,shape_para,scale_para)
%%function to calculate the left integration x*\phi(x) from  lo to up
f=@(x) x.* wblpdf(x,scale_para,shape_para);
result = integral(f,lo,up);
end

