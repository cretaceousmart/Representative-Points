function PLOT(data)
%Parameter Setting
n = 30:30:300;
axis([0 300 0 1])
set(gca,'xtick',0:30:300);
%===================================================================
%Plot
subplot(131)
plot(n,data(1,:),'.-','Color','g','LineWidth',1.5)
hold on 
plot(n,data(2,:),'Marker','+','Color','b')
hold on 
plot(n,data(3,:),'Marker','x')
hold on 
plot(n,data(4,:),'Marker','.')
hl = legend('MSE-RP x^2','x^2','KS','AD');
set(hl,'Box','off','Location','southeast')
title('Chisquare(20)  m = 10')%,<=================================Title
xlabel('sample size')
ylabel('Power')

subplot(132)
plot(n,data(5,:),'.-','Color','g','LineWidth',1.5)
hold on 
plot(n,data(6,:),'Marker','+','Color','b')
hold on 
plot(n,data(7,:),'Marker','x')
hold on 
plot(n,data(8,:),'Marker','.')
hl = legend('MSE-RP x^2','x^2','KS','AD');
set(hl,'Box','off','Location','southeast')
title('Chisquare(20)  m = 20')%<=================================Title
xlabel('sample size')
ylabel('Power')

subplot(133)
plot(n,data(9,:),'.-','Color','g','LineWidth',1.5)
hold on 
plot(n,data(10,:),'Marker','+','Color','b')
hold on 
plot(n,data(11,:),'Marker','x')
hold on 
plot(n,data(12,:),'Marker','.')
hl = legend('MSE-RP x^2','x^2','KS','AD');
set(hl,'Box','off','Location','southeast')
title('Chisquare(20)  m = 30')%<=================================Title
xlabel('sample size')
ylabel('Power')

end