function  x=tnewton1(x0,eps,n)

x1=x0;x2=x0+1.5;
f=G(0,n)-G((x1+x2)/2,n)-x1*(tcdf((x1+x2)/2,n)-tcdf(0,n));
dif=(x1+x2)*tpdf((x1+x2)/2,n)/4-x1*tpdf((x1+x2)/2,n)/2;
x(1)=x1;
x(2)=x2-f/dif;
k=1;
while abs(x(2)-x2)>eps
    k=k+1;
    x2=x(2);
    f=G(0,n)-G((x1+x2)/2,n)-x1*(tcdf((x1+x2)/2,n)-tcdf(0,n));
    dif=(x1+x2)*tpdf((x1+x2)/2,n)/4-x1*tpdf((x1+x2)/2,n)/2;
    x(2)=x2-f/dif;   
end 
x;


end

