% a program for generating the uniform distri. on the unit sphere of R^p
% by number-theoretic methods described in Fang and Wang's book
% p.166-170

    function x=spu(n,p);

% n: the sample size
% p is the dimension of the sphere
% x is nxp matrix

if p >= 4
      if rem(p,2)==0
         x=spevenu(n,p);
      else
         x=spoddu(n,p);
      end
end
if p<= 3
   if p==1, x=2*rand(n,p)-1; end;
   if p==2, x=speven2u(n); end
   if p==3,  x=spodd3u(n); end
end





