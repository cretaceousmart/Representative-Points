%������
%%
function power = Main(n,k,N,normal_RP_data)%�����ֱ�Ϊ������������һ�������������������
format long
alpha = 0.03;
m = 2*k;

%����������
normal_RP = normal_RP_data(m,1:m/2);

%����ͳ����
method_1_x_square = chi2inv(1-alpha,m-3);

i = 1;
I_1 = zeros(N,1);I_2 = zeros(N,1);I_3 = zeros(N,1);
I_4 = zeros(N,1);% I_5 = zeros(N,1);I_6 = zeros(N,1);

% %��Чģ��
while i<=N
%    Step1.Generate random number of H1
%random_number = random(dist,n,1);



%random_number = kotzNrs(n,1,4.5,0.5,4);
%Cauchy:
% random_number = zeros(n,1);
% counter = 1;
% while counter <=n
%    a = trnd(1,1,1);
%    if abs(a)<=5
%        random_number(counter) = a;
%        counter = counter+1;
%    end
% end
%=================================================================================
%Type 1
%    random_number = random('t',5,n,1);%t�ֲ�
%    random_number = random('Logistic',0,1,n,1);%Logistics�ֲ�

% random_number = [62,66,78,79,80,84,84,85,85,86,86,87,88,88,89,89,91,91,91,91,92,92,92,92,93,94,94,94,95,95,95,96,96,96,96,96,97,97,97,97,97,97,98,98,98,98,98,98,98,99,99,99,99,99,100,100,100,100,100,101,101,101,101,102,102,102,102,102,102,102,103, 103,103,103,104,104,104,104,104,104,105,105,106,107,107,109,110,111,111,111,114,115,117,122,132,132,137,137,138]';


%=================================================================================
% mu=0;                      %��ֵ
% b=1;      %���ݱ�׼������Ӧ��b
% 
% a=rand(1,n)-0.5;    %����(-0.5,0.5)�����ھ��ȷֲ���������� (һ�������������);
% 
% random_number = mu-b*sign(a).*log(1-2*abs(a)); %���ɷ���������˹�ֲ����������
%=================================================================================
% Double exponential with density function f(x) = (1/2) exp(?|x|).

% random_number = zeros(n,1);
% j= 1;
% while j <=n
%     u_1 = random('Normal',0,1,1,1);
%     u_2 = rand(1,1);
%     fx = 0.5*exp(-abs(u_1));
%     if u_2<=fx
%        random_number(j) = u_1;
%        j = j+1;
%     end
% end
%=================================================================================
%Type 2
beta =5;
random_number = zeros(n,1);
j= 1;
while j <=n
    u_1 = random('Normal',0,1,1,1);
    u_2 = rand(1,1);
    fx = beta/(2*gamma(beta))*exp(-1*(abs(u_1)).^beta);
    if u_2<=fx
       random_number(j) = u_1;
       j = j+1;
    end
end
%=================================================================================
%Type 3
% random_number = random('Chisquare',20,n,1);
%=================================================================================
%random_number = random('Lognormal',1,1,n,1);
% shift = mean(random_number);
% random_number = random_number-shift;
%=================================================================================
% Shift Weibull
% random_number = random('Weibull',3,4,n,1);
% shift = mean(random_number);
% random_number = random_number-shift;
% %=================================================================================
%     
%    Step2.Generate RP for specific normal distribution and adjustment of random number
%     Method 1 ��Ҫ�����ֵ�ͱ�׼��
    miu = mean(random_number);
%     sigma2 = sum((random_number-miu).^2)/n;
%     sigma = sqrt(sigma2);
    sigma = std(random_number);
    normal_RP_method_1 = miu+sigma.*normal_RP;
    
%     Method 2 ��Ҫ�����׼��
%     random_number_method_2 = zeros((n-1),1);
%     for j = 1:(n-1)
%         random_number_method_2(j) = (sum(random_number(1:j))-j*random_number(j+1))/sqrt(j*(j+1));
%     end
%     sigma_method_2 = std(random_number_method_2);
%     normal_RP_method_2 = sqrt(sigma_method_2).*normal_RP;
    
%     Method 3 
%     t_random_number = random_number;
%     t_miu = mean(t_random_number);
%     t_sigma = std(t_random_number);
%     random_number_method_3 = (t_random_number-t_miu)/t_sigma;
%     t_RP_method_3 = t_RP; %t�ֲ������� ��Run�в���������
  
%    Step3. Simulation with different method/random number/x_square/RP
    
   I_1(i) = MSE_RP_Method_1(random_number,normal_RP_method_1,n,k,method_1_x_square,miu,sigma,m);%MSE-RP Chi-square test
   %I_2(i) = MSE_RP_Method_2(random_number_method_2,normal_RP_method_2,n-1,k,method_2_x_square,sigma_method_2);%MSE-RP Chi-square test
   %I_3(i) = MSE_RP_Method_3(random_number_method_3,t_RP_method_3,n,k,method_3_x_square);%MSE-RP Chi-square test
   I_2(i) = Original_Chi_Method(random_number,n,k,method_1_x_square);%Original Chi-square test
   
   
   %for logistic
%    b = sigma*sqrt(3)/pi;
%    dist =  makedist('Logistic','mu',miu,'sigma',b);
%    I_3(i) = kstest(random_number,'cdf',dist,'Alpha',0.05);%ks test
%    I_4(i) = adtest(random_number,'Distribution',dist);
    %I_6(i) = swtest(random_number,0.04);%sw test
   i = i+1;
end

power_1 = sum(I_1)/N;
power_2 = sum(I_2)/N;
power_3 = sum(I_3)/N;
power_4 = sum(I_4)/N;
%power_5 = sum(I_5)/N;
%power_6 = sum(I_6)/N;
power = [power_1;power_2;power_3;power_4];
end

%===================================================================================================================
% % % Simulation of Type I Error
% while i<=N
% %    Step1.Generate random number of H1
%     random_number = random('Normal',3,2,n,1);
%     
%     
% %    Step2.Generate RP for specific normal distribution and adjustment of random number
% %     Method 1 ��Ҫ�����ֵ�ͱ�׼��
%     miu = mean(random_number);
%     sigma2 = sum((random_number-miu).^2)/n;
%     sigma = sqrt(sigma2);
%     normal_RP_method_1 = miu+sigma.*normal_RP;
%     
% %     Method 2 ��Ҫ�����׼��
% %     random_number_method_2 = random('Normal',0,2,(n-1),1);
%     random_number_method_2 = zeros(n,1);
%     for j = 1:(n-1)
%         random_number_method_2(j) = (sum(random_number(1:j))-j*random_number(j+1))/sqrt(j*(j+1));
%     end
%     miu_method_2 = mean(random_number_method_2);
%     sigma2_method_2 = sum((random_number_method_2-miu_method_2).^2)/(n-1);
%     sigma_method_2 = sqrt(sigma2_method_2);
%     normal_RP_method_2 = sqrt(sigma2_method_2).*normal_RP;
%     
% %     Method 3 
%     t_random_number = random_number;
%     t_miu = mean(t_random_number);
%     t_sigma2 = sum((t_random_number-t_miu).^2)/n;
%     t_sigma = sqrt(t_sigma2);
%     random_number_method_3 = (t_random_number-t_miu)/t_sigma;
%     t_RP_method_3 = t_RP; %t�ֲ������� ��Run�в���������
%     
%       
% %    Step3. Simulation with different method/random number/x_square/RP
%     
%    I_1(i) = MSE_RP_Method_1(random_number,normal_RP_method_1,n,k,method_1_x_square,miu,sigma);%MSE-RP Chi-square test
%    I_2(i) = MSE_RP_Method_2(random_number_method_2,normal_RP_method_2,n-1,k,method_2_x_square,sigma_method_2);%MSE-RP Chi-square test
%    I_3(i) = MSE_RP_Method_3(random_number_method_3,t_RP_method_3,n,k,method_3_x_square);%MSE-RP Chi-square test
%    I_4(i) = Original_Chi_Method(random_number,n,k,method_1_x_square);%Original Chi-square test
%    
% %    dist =  makedist('Normal','mu',miu,'sigma',sigma);
% %    I_5(i) = kstest(random_number,'cdf',dist,'Alpha',0.05);%ks test
% %    I_6(i) = swtest(random_number,0.04);%sw test
%    i = i+1;
% end
% 
% power_1 = sum(I_1)/N;
% power_2 = sum(I_2)/N;
% power_3 = sum(I_3)/N;
% power_4 = sum(I_4)/N;
% power = [power_1;power_2;power_3;power_4];
% end

