%ע��H0�ֲ��ı�ʱ��pi������Ҫ�޸�
%%
function f = Original_Chi_Method(random_variable,n,k,x_square,m)
%Calculate the mi and pi

    miu = mean(random_variable);
%     sigma2 = sum((random_variable-miu).^2)/n;
    sd = std(random_variable);
%     %��̬�ֲ�
%     chi_pi = 1/(2*k):1/(2*k):1;
%     pd = makedist('Normal','mu',miu,'sigma',sd);
%     chi_RP = icdf(pd,chi_pi(1:2*k-1));
%     %Laplace�ֲ�
%     chi_pi = 1/(2*k):1/(2*k):1;
%     chi_RP = zeros(1,2*k-1);
%     for i = 1:length(chi_RP)
%         chi_RP(i) = inv_lacdf(chi_pi(i),0,1);
%     end
      chi_pi = 1/(2*k):1/(2*k):1;
      b = sd*sqrt(3)/3.141592653589793;
      pd = makedist('Logistic','mu',miu,'sigma',b);
      chi_RP = icdf(pd,chi_pi(1:2*k-1));

    chi_mi = zeros(2*k,1);
   
%     
%     subplot(121)
%     miu = 1;
%     sd = 1;
%     pd = makedist('Normal','mu',miu,'sigma',sd);
%     x = -5:0.1:5;
%     plot(x,pdf(pd,x));
%     hold on 
%     
%     k = 10;
%     chi_pi = 1/(2*k):1/(2*k):1;
%     chi_RP = icdf(pd,chi_pi(1:2*k-1));
% %     plot(chi_RP,pdf(pd,chi_RP))
%     
%     for i = 1:19
%         text(chi_RP(i),pdf(pd,chi_RP(i)),'.','linewidth',3);
%         hold on
%         
%     end
%     
%     subplot(122)
%     miu = 0;
%     sd = 1;
%     pd = makedist('Normal','mu',miu,'sigma',sd);
%     x = -5:0.1:5;
%     plot(x,pdf(pd,x));
%     hold on 
%     k = 10;
%     chi_pi = 1/(2*k):1/(2*k):1;
%     chi_RP = icdf(pd,chi_pi(1:2*k-1));
%     for i = 1:19
%         text(chi_RP(i),pdf(pd,chi_RP(i)),'.','linewidth',3);
%         hold on
%         
%     end
    
    
    
    
    %for mi
    %�����
    for  h = 1:n 
       if random_variable(h)<chi_RP(1)
           chi_mi(1) = chi_mi(1)+1;
       end
    end
    %���ұ�
    for  h = 1:n 
       if random_variable(h)>chi_RP(2*k-1)
           chi_mi(2*k) = chi_mi(2*k)+1;
       end
    end      
    %�м䲿��
    for j = 1:(2*k-2)
       for h = 1:n
           if random_variable(h)>=chi_RP(j)&&random_variable(h)<=chi_RP(j+1)
               chi_mi(j+1) = chi_mi(j+1)+1;
           end
       end
    end
    
    
    %Calculate the statistic
    chi_x_square = 0;
    pi = 1/(2*k);
    for i = 1:2*k
        chi_x_square = chi_x_square+((chi_mi(i)-n*pi).^2)/(n*pi);
    end

    %Comparison
%     x_square = chi2inv(1-alpha,k-3);
    if chi_x_square>=x_square %Reject H0
        f = 1;
        %f = [1,x_square,chi_x_square,(1-chi2cdf(chi_x_square,m-3))];
    else
        f = 0;
%         f = [0,x_square,chi_x_square,(1-chi2cdf(chi_x_square,m-3))];
    end


end