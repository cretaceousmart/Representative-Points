function  [x,xl]=tnewton2(x0,l,eps,n)

x=tnewton1(x0,eps,n);
for i=3:l
 xi=x(i-1)+0.5;
 f=G((x(i-2)+x(i-1))/2,n)-G((x(i-1)+xi)/2,n)-x(i-1)*(tcdf((x(i-1)+xi)/2,n)-tcdf((x(i-2)+x(i-1))/2,n));
 dif=(x(i-1)+xi)*tpdf((x(i-1)+xi)/2,n)/4-x(i-1)*tpdf((x(i-1)+xi)/2,n)/2;
 x(i)=xi-f/dif;
 k=1;
while abs(x(i)-xi)>eps
    k=k+1;
    xi=x(i);
 f=G((x(i-2)+x(i-1))/2,n)-G((x(i-1)+xi)/2,n)-x(i-1)*(tcdf((x(i-1)+xi)/2,n)-tcdf((x(i-2)+x(i-1))/2,n));
 dif=(x(i-1)+xi)*tpdf((x(i-1)+xi)/2,n)/4-x(i-1)*tpdf((x(i-1)+xi)/2,n)/2;
 x(i)=xi-f/dif;
end
 end
 x;
 xl=x(l);


end

