x = -10:0.01:100;
miu = 3;b = 1;
y_1 = 1/(2*b)*exp(-abs(x-miu)/b);
y_2 = pdf('Logistic',x,3,1);
y_3 = pdf('Weibull',x,3,3);
y_4 = pdf('Normal',x,3,1);
y_5 = pdf('Chisquare',x,15);


plot(x,y_1);
hold on 
plot(x,y_2);
hold on 
plot(x,y_3);
hold on 
plot(x,y_4);
hold on 
plot(x,y_5);
hl = legend('Laplace(3,1)','Logistic(3,1)','Normal(3,1)','Weibull(3,3)','Chisquare(20)');