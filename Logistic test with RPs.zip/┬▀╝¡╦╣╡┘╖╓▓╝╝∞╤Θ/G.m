function y=G(x,n)
%UNTITLED3 Summary of this function goes here
%   Detailed explanation goes here
y=n*tpdf(x,n)*(1+x^2/n)/(n-1);

end

