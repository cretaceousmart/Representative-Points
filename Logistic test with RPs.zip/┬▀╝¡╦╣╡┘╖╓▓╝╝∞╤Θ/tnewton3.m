function  xL=tnewton3(x0,l,eps,n)

[x,xl]=tnewton2(x0,l,eps,n);
xa=x(l-1)+0.5;
f=G((x(l-1)+xa)/2,n)-xa+xa*tcdf((x(l-1)+xa)/2,n);
dif=((xa-x(l-1))/4)*tpdf((x(l-1)+xa)/2,n)+tcdf((x(l-1)+xa)/2,n)-1;
xL=xa-f/dif;
k=1;
while abs(xL-xa)>eps
    k=k+1;
    xa=xL;
    f=G((x(l-1)+xa)/2,n)-xa+xa*tcdf((x(l-1)+xa)/2,n);
    dif=((xa-x(l-1))/4)*tpdf((x(l-1)+xa)/2,n)+tcdf((x(l-1)+xa)/2,n)-1;
   xL=xa-f/dif;   
end 
xL;

end

