function F = lacdf(X,miu,b)
syms x 
f(x) = 1/(2*b)*exp(-(x-miu)/b);
k1 = int(f,x,0,X);
F = double(k1)+0.5;
end

