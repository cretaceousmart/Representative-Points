%this program is devised by Li Run-Ze and revised by Liang Jiajuan
%n is the sample size, p=dim
%N, r and s are parameters
%this program requires (2*N+d-2)/s must be an integer

function y=kotzNrs(n,p,N,r,s);  %y is an n times p matrix

%This program is used to generate p-dimensional 
% Kotz-type distribution with N (integer), s=1, r;
% The definition of Kotz-type distribution can see Fang-Kotz-Ng (1990),
% Section 3.2. The sample size is n.
%if (2*N+p-2)/s==floor((2*N+p-2)/s)
%R=sqrt(xisquare(n,1,(p+2*N-2)/s)/2/r).^(1/s);
a=(2*N+p-2)/(2*s);
b=1/r;
R=(gamrnd(a,b,n,1)).^(.5/s);
uniform=spu(n,p);  %uniform distr. on the unit sphere of R^d
y=uniform.*(R*ones(1,p));
%else
%'(2*N+p-2)/s is not an integer, try again'
%end
