clear;clc;
new_t_RP_m10 = zeros(5,10); %ȡ10��������

for i = 1:10
n = (100*i)-1; %���ɶ� = n-1
eps = 10^(-8);
k = 5;
x0=2*G(0,n);e = eps;
f = trepointeven(x0,k,e,eps,n);
new_t_RP_m10(:,i) = f;
end

xlswrite('C:\ѧϰ\FYP\��һƪ����\Simulation\1000_t_RP_m10.xlsx',new_t_RP_m10);

%========================================================================

new_t_RP_m20 = zeros(10,10); %ȡ20��������

for i = 1:10
n = (100*i)-1;
eps = 10^(-8);
k = 10;
x0=2*G(0,n);e = eps;
f = trepointeven(x0,k,e,eps,n);
new_t_RP_m20(:,i) = f;
end

xlswrite('C:\ѧϰ\FYP\��һƪ����\Simulation\1000_t_RP_m20.xlsx',new_t_RP_m20);

%========================================================================

new_t_RP_m30 = zeros(15,10); %ȡ30��������

for i = 1:10
n = (100*i)-1;
eps = 10^(-8);
k = 15;
x0=2*G(0,n);e = eps;
f = trepointeven(x0,k,e,eps,n);
new_t_RP_m30(:,i) = f;
end

xlswrite('C:\ѧϰ\FYP\��һƪ����\Simulation\1000_t_RP_m30.xlsx',new_t_RP_m30);