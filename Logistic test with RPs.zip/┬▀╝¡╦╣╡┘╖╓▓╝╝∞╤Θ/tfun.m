function X=tfun(X1,l,e,eps,n)
% n=10;l=30;e=10^(-8);
% X1=2*G(0,n); eps=10^(-8);
format long
x0=X1/(l+1);
LP=0;
RP=X1;
[x,xl]=tnewton2(x0,l,eps,n);
 xL=tnewton3(x0,l,eps,n);

 
  k=1;
 while abs(xl-xL)>e
    k=k+1;
    if  xl<=xL-e
     LP=x0;
     x0=(LP+RP)/2;
     [x,xl]=tnewton2(x0,l,eps,n);
     xL=tnewton3(x0,l,eps,n);
    elseif xl>=xL+e
        RP=x0;
        x0=(LP+RP)/2;
       [x,xl]=tnewton2(x0,l,eps,n);
       xL=tnewton3(x0,l,eps,n); 
    end
 end
X=x;


end

