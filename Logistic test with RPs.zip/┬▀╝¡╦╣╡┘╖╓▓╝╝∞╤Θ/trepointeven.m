function f=trepointeven(x0,l,e,eps,n)
X(1)=x0;
for i=2:l
    X=tfun(X(1),i,e,eps,n);
end
f = X;
% b=[rot90(rot90(-X)),X];
% y=1-tlossfun(b,n);

end


