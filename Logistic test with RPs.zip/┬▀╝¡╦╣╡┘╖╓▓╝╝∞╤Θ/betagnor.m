%this program is for generating beta-generalized normal distribution N(0,I_p,beta) with
%density b^p*r^(p/b)/[2^p*gamma^p(1/b)]*exp{-r*\sum_{i=1}^p|x_i|^p}, b=beta

function x=betagnor(n,s,p)
z=rand(n,s);
y=sign(2*z-1).*(p*gaminv((2*z-1).*sign(2*z-1),1/p,1)).^(1/p);
py=abs(y').^p;
npy=sum(py).^(1/p);
uy=y'./(ones(s,1)*npy);
x=uy';
yr=chi2rnd(8*s,n,1);
R=(2*yr).^4;
x=diag(R)*x; %l_p norm normal