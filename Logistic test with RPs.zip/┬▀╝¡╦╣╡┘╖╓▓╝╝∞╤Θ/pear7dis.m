%this program is devised by Li Run-Ze and revised by Liang Jiajuan
%n is the sample size, p is the dim of Pearson type 7 distr.
% m and N are the parameters. N>p/2, m>0.

function y=pear7dis(n,p,m,N)
%This program is used to generate multivariate Pearson VII type  

%v=betadist(n,1,p/2,N-p/2);
v=betarnd(p/2,N-p/2,n,1);
%r=sqrt(m*(N-p/2)*v./(1-v));
r=sqrt(m*v./(1-v));
uniform=spu(n,p);  % uniform distr. on the unit sphere in R^p
y=uniform.*(r*ones(1,p));

