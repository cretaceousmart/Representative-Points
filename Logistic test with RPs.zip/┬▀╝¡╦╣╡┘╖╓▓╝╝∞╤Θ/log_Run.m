%Simulation for Logistics:
clc;clear;
n  = 100:100:3000;N = 300; %�������
size = length(n);
RP_data = xlsread('.\Logistics.xlsx',1);
result_m10 = zeros(4,size);result_m20 = zeros(4,size);result_m30 = zeros(4,size);
dist = makedist('Beta',2,2);
for i = 1:size
    result_m10(:,i) = Main(n(i),5,N,RP_data,dist); % m = 10
    result_m20(:,i) = Main(n(i),10,N,RP_data,dist);% m = 20
    result_m30(:,i) = Main(n(i),15,N,RP_data,dist);% m = 30
end
total_result_1 = [result_m10;result_m20;result_m30];
xlswrite('.\result\total_result_1.xlsx',total_result_1)
%================================================================================
clc;clear;
n  = 300:300:3000;N = 300; %�������
size = length(n);
RP_data = xlsread('.\Logistics.xlsx',1);
result_m10 = zeros(4,size);result_m20 = zeros(4,size);result_m30 = zeros(4,size);
dist = makedist('Beta',2,5);
for i = 1:size
    result_m10(:,i) = Main(n(i),5,N,RP_data,dist); % m = 10
    result_m20(:,i) = Main(n(i),10,N,RP_data,dist);% m = 20
    result_m30(:,i) = Main(n(i),15,N,RP_data,dist);% m = 30
end
total_result_2 = [result_m10;result_m20;result_m30];
xlswrite('.\result\total_result_2.xlsx',total_result_2)
%================================================================================
clc;clear;
n  = 300:300:3000;N = 300; %�������
size = length(n);
RP_data = xlsread('.\Logistics.xlsx',1);
result_m10 = zeros(4,size);result_m20 = zeros(4,size);result_m30 = zeros(4,size);
dist = makedist('Stable',1,0,1,0);
for i = 1:size
    result_m10(:,i) = Main(n(i),5,N,RP_data,dist); % m = 10
    result_m20(:,i) = Main(n(i),10,N,RP_data,dist);% m = 20
    result_m30(:,i) = Main(n(i),15,N,RP_data,dist);% m = 30
end
total_result_3 = [result_m10;result_m20;result_m30];
xlswrite('.\result\total_result_3.xlsx',total_result_3)
%==============================================================================


clc;clear;
n  = 100:100:1500;N = 100; %�������
size = length(n);
RP_data = xlsread('.\Logistics.xlsx',1);
result_m10 = zeros(4,size);result_m20 = zeros(4,size);result_m30 = zeros(4,size);
dist = makedist('Logistic',0,1);
for i = 1:size
    result_m10(:,i) = Main(n(i),2,N,RP_data,dist); % m = 10
    result_m20(:,i) = Main(n(i),3,N,RP_data,dist);% m = 20
    result_m30(:,i) = Main(n(i),4,N,RP_data,dist);% m = 30
end
total_result = [result_m10;result_m20;result_m30];
PLOT(total_result)

xlswrite('.\result\total_result_4.xlsx',total_result_4)








clc;clear;
n  = 50:50:500;N = 2000; %�������
size = length(n);
RP_data = xlsread('.\Logistics.xlsx',1);
result_m10 = zeros(4,size);result_m20 = zeros(4,size);result_m30 = zeros(4,size);
for i = 1:size
    result_m10(:,i) = Main(n(i),3,N,RP_data); % m = 6
    result_m20(:,i) = Main(n(i),4,N,RP_data);% m = 8
    result_m30(:,i) = Main(n(i),5,N,RP_data);% m = 10
    fprintf('%d\n',i);
end
total_result = [result_m10;result_m20;result_m30];
PLOT(total_result)
%�����֣���������
xlswrite('.\result\new_beta5.xlsx',total_result)

% 
% a = xlsread('C:\ѧϰ\FYP\Code\�߼�˹�ٷֲ�����\result\log_type1.xlsx');
% PLOT(a)


random_number = [62,66,78,79,80,84,84,85,85,86,86,87,88,88,89,89,91,91,91,91,92,92,92,92,93,94,94,94,95,95,95,96,96,96,96,96,97,97,97,97,97,97,98,98,98,98,98,98,98,99,99,99,99,99,100,100,100,100,100,101,101,101,101,102,102,102,102,102,102,102,103, 103,103,103,104,104,104,104,104,104,105,105,106,107,107,109,110,111,111,111,114,115,117,122,132,132,137,137,138]';





%real data
clear;clc;
% n_tree = [80,154,132,25,190,74,50,45,65,83,74,75,90,82,64,77,80,83,108,123,87,102,104,103,118,81,82,94,108]';
% d_tree = [10,9,11,30.7,5.7,9.2,21.6,20.4,16.6,13.9,14.45,14,14.9,14.8,16.1,13.8,13.6,13,13.6,12.7,12.7,13.8,12.6,13.8,12.4,14.2,14,14.4,13.9]';
n_tree = [16,16,16,16,16,16,16,16,16,12]';
d_tree = [16,16,16,15,15,15,15,8,1,0];
n = zeros(sum(n_tree),1);
old_counter = 1;
for i = 1:10
   new_counter = n_tree(i);
   n(old_counter:old_counter+new_counter-1) = d_tree(i);
   old_counter = old_counter+new_counter;
end




clear;clc
format long
alpha = 0.05;
k = 5;
n = 121;
m = 2*k;
RP_data = xlsread('.\Logistics.xlsx',1);
normal_RP = RP_data(m,1:m/2);

n1 = [ 0.3, 0.3, 4.0, 5.0, 5.6, 6.2, 6.3, 6.6, 6.8, 7.4, 7.5, 8.4, 8.4, 10.3];
n2 = [11.0, 11.8, 12.2, 12.3, 13.5, 14.4, 14.4, 14.8, 15.5, 15.7, 16.2, 16.3, 16.5, 16.8, 17.2, 17.3, 17.5];
n3 = [17.9, 19.8, 20.4, 20.9, 21.0, 21.0, 21.1, 23.0, 23.4, 23.6, 24.0, 24.0, 27.9, 28.2, 29.1, 30.0, 31.0];
n4=[31.0, 32.0, 35.0, 35.0, 37.0, 37.0, 37.0, 38.0, 38.0, 38.0, 39.0, 39.0, 40.0, 40.0, 40.0, 41.0, 41.0];
n5=[41.0, 42.0, 43.0, 43.0, 43.0, 44.0, 45.0, 45.0, 46.0, 46.0, 47.0, 48.0, 49.0, 51.0, 51.0, 51.0, 52.0];
n6=[54.0, 55.0, 56.0, 57.0, 58.0, 59.0, 60.0, 60.0, 60.0, 61.0, 62.0, 65.0, 65.0, 67.0, 67.0, 68.0, 69.0];
n7=[78.0, 80.0,83.0, 88.0, 89.0, 90.0, 93.0, 96.0, 103.0, 105.0, 109.0, 109.0, 111.0, 115.0, 117.0, 125.0];
n8= [126.0, 127.0, 129.0, 129.0, 139.0, 154.0];
N = [n1,n2,n3,n4,n5,n6,n7,n8];

for i = 1:121
    N(i) = log(N(i));
end
random_number = N';
% random_number = [62,66,78,79,80,84,84,85,85,86,86,87,88,88,89,89,91,91,91,91,92,92,92,92,93,94,94,94,95,95,95,96,96,96,96,96,97,97,97,97,97,97,98,98,98,98,98,98,98,99,99,99,99,99,100,100,100,100,100,101,101,101,101,102,102,102,102,102,102,102,103, 103,103,103,104,104,104,104,104,104,105,105,106,107,107,109,110,111,111,111,114,115,117,122,132,132,137,137,138]';
% random_number = random('Logistic',0,1,n,1);%Logistics�ֲ�
miu = mean(random_number);
sigma = std(random_number);
b = sigma.*sqrt(3)/3.14159265358;
RP = miu+b.*normal_RP; 
x_square = chi2inv(1-alpha,m-3);

f1 = MSE_RP_Method_1(random_number,RP,n,k,x_square,miu,sigma,m)
f2 = Original_Chi_Method(random_number,n,k,x_square,m)

dist =  makedist('Logistic','mu',miu,'sigma',b);

[h,p] = adtest(random_number,'Distribution',dist)
[h,p] = kstest(random_number,'cdf',dist,'Alpha',0.05)

















