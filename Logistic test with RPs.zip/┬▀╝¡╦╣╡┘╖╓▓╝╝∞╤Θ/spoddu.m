% Subroutines for generating the uniform distr. on the unit sphere of
% R^p, p=dim of the sphere is odd and larger than 3

function x=spoddu(n,p)

% x is nxp matrix

%C=glp(n,vec);
C=rand(n,p-1);
[n,s]=size(C);
p1=s/2;
power=ones(n,1)*[3:2:2*p1-1];
power=2 ./ power;
Cp=C(:,1:p1-1).^power;
if p1==2
Hp=Cp(:,1);
else
Cp=rot90(Cp);
Cp=cumprod(Cp);
Hp=rot90(Cp,3);
end;
DH1=[zeros(n,1) Hp];
DH2=[Hp ones(n,1)];
D=sqrt(DH2-DH1);
ap=C(:,p1).*(1-C(:,p1));
ap1=2*pi*C(:,p1+1);
x=zeros(n,s+1);
x(:,1)=D(:,1).*(1-2*C(:,p1));
x(:,2)=2*D(:,1).*sqrt(ap).*cos(ap1);
x(:,3)=2*D(:,1).*sqrt(ap).*sin(ap1);
G=2*pi*C(:,2*[2:p1]);      % n*(p1-1) matrix
even=2*[2:p1];
odd=2*[2:p1]+1;
x(:,even)=D(:,2:p1).*cos(G);
x(:,odd)=D(:,2:p1).*sin(G);



