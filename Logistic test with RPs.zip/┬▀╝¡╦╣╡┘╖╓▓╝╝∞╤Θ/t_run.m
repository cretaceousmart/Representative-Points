clc;clear;
n = 50:50:500;
N = 50; %�������
size = length(n);

t_RP_m10 =  xlsread('C:\ѧϰ\FYP\�ڶ�ƪ����\������\t\t_RP_m10.xlsx',1);
t_RP_m20 =  xlsread('C:\ѧϰ\FYP\�ڶ�ƪ����\������\t\t_RP_m20.xlsx',1);
t_RP_m30 =  xlsread('C:\ѧϰ\FYP\�ڶ�ƪ����\������\t\t_RP_m30.xlsx',1);
    

result_m10 = zeros(2,size);
result_m20 = zeros(2,size);
result_m30 = zeros(2,size);
for i = 1:size
    result_m10(:,i) = t_Main(n(i),5,N,t_RP_m10(:,i)); % m = 10
    
    result_m20(:,i) = t_Main(n(i),10,N,t_RP_m20(:,i) );% m = 20
    
    result_m30(:,i) = t_Main(n(i),15,N,t_RP_m30(:,i) );% m = 30
end

total_result = [result_m10;result_m20;result_m30];
xlswrite('C:\ѧϰ\FYP\�ڶ�ƪ����\Simulation���\t�ֲ�\N(2,2).xlsx',total_result)

%plot
data = xlsread('C:\ѧϰ\FYP\�ڶ�ƪ����\Simulation���\t�ֲ�\N(2,2).xlsx',1);

n = 50:50:500;
subplot(131)
m10_data = data(1:2,:);
plot(n,m10_data(1,:),'.-','Color','g','LineWidth',1.5)
hold on 
plot(n,m10_data(2,:),'.-','LineWidth',1.5,'Color','r')
hold on 
set(gca,'xtick',50:50:500);
% set(gca,'ytick',0:0.1:1);
hl = legend('MSE-RP x^2','x^2');
set(hl,'Box','off','Location','southeast')
title('N(2,2) m = 10')
xlabel('sample size')
ylabel('Power')

subplot(132)
m20_data = data(3:4,:);
plot(n,m20_data(1,:),'.-','Color','g','LineWidth',1.5)
hold on 
plot(n,m20_data(2,:),'.-','LineWidth',1.5,'Color','r')
hold on 
set(gca,'xtick',50:50:500);
% set(gca,'ytick',0:0.1:1);
hl = legend('MSE-RP x^2','x^2');
set(hl,'Box','off','Location','southeast')
title('N(2,2) m = 20')
xlabel('sample size')
ylabel('Power')

subplot(133)
m30_data = data(5:6,:);
plot(n,m30_data(1,:),'.-','Color','g','LineWidth',1.5)
hold on 
plot(n,m30_data(2,:),'.-','LineWidth',1.5,'Color','r')
hold on 
set(gca,'xtick',50:50:500);
% set(gca,'ytick',0:0.1:1);
hl = legend('MSE-RP x^2','x^2');
set(hl,'Box','off','Location','southeast')
title('N(2,2) m = 30')
xlabel('sample size')
ylabel('Power')