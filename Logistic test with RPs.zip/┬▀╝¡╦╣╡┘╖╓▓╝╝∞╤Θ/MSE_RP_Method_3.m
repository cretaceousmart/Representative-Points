function f = MSE_RP_Method_3(random_variable,RP,n,k,x_square)
%Calculate the mi and pi
    mi = zeros(2*k,1);
    pi = zeros(2*k,1);
    BP = zeros(k-1,1);
    for i = 1:k-1
       BP(i) = 0.5*(RP(i)+RP(i+1)); 
    end
    a = zeros(k-1,1);
    for i = 1:k-1
        a(i) = -BP(k-i);
    end
    BP = [a;0;BP];
    
    
    %for mi
    %�����
    h = 1;
    while h<=n
       if random_variable(h)<BP(1)
           mi(1) = mi(1)+1;
       end
        h = h+1;
    end
    
    %���ұ�
    h = 1;
    while h<=n
       if random_variable(h)>BP(2*k-1)
           mi(2*k) = mi(2*k)+1;
       end    
        h = h+1;
    end
    
    %�м䲿��
    j = 1;
    while j <=(2*k-2)
        h = 1;
        while h<=n
           if random_variable(h)>=BP(j)&&random_variable(h)<=BP(j+1)
               mi(j+1) = mi(j+1)+1;
           end
           h = h+1; 
        end
       
        j = j+1;
    end
    
 

    %for pi
    pi(1) = tcdf(BP(1),(n-1));pi(k) = tcdf(0,(n-1))-tcdf(BP(k-1),(n-1));
    
    i = 2;
    while i<=k-1
       pi(i) = tcdf(BP(i),(n-1))- tcdf(BP(i-1),(n-1));
       i = i+1;
    end
    
    a = pi;   
    i = 1;
    while i<=k
        pi(k+i) = a(k-i+1); 
        i = i+1;
    end
    
    %Step5.Calculate the statistic
    mse_x_square = 0;
    for i = 1:2*k
       mse_x_square = mse_x_square+((mi(i)-n*pi(i))^2)/(n*pi(i)); 
    end
    
    %Step6.Comparison
%     x_square = chi2inv(1-alpha,k-3);
    if mse_x_square>=x_square %Reject H0
        f = 1;
    else
        f = 0;
    end

end