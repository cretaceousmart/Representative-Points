n = 100;
random_number = random('t',5,n,1)';
%�����
miu = mean(random_number);
b = sqrt(3)/pi*std(random_number);
for i = 1:length(random_number)
   cdf(i) = lacdf(random_number(i),miu,b); 
end
kstest(random_number,[random_number;cdf]',0.05)

