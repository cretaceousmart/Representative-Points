% a subroutine for generating NT-Net set on a unit ciricle of
% 2-dimension space
% subfile name: speven2.m

function x=speven2(n,vec);

% acturally, vec=[], a empty vector

a=[1:2:2*n-1]'/n/2;       % a net set on [0,1] of 1-dimension space
b=2*pi*a;
x=zeros(n,2);
x(:,1)=cos(b);
x(:,2)=sin(b);




