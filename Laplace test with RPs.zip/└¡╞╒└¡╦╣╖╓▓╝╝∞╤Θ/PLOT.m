function PLOT(data)
%Parameter Setting
n = 30:30:300;
axis([0 300 0 1])
set(gca,'xtick',0:30:300);
%===================================================================
%Plot
subplot(131)
plot(n,data(1,:),'.-','Color','g','LineWidth',1.5)
hold on 
plot(n,data(2,:),'Marker','+','Color','b')
hold on 
plot(n,data(3,:),'Marker','x')
hl = legend('MSE-RP x^2','x^2','KS');
set(hl,'Box','off','Location','southeast')
title('Chisquare(20)  m = 10')%,<=================================Title
xlabel('sample size')
ylabel('Power')

subplot(132)
plot(n,data(4,:),'.-','Color','g','LineWidth',1.5)
hold on 
plot(n,data(5,:),'Marker','+','Color','b')
hold on 
plot(n,data(6,:),'Marker','x')

hl = legend('MSE-RP x^2','x^2','KS');
set(hl,'Box','off','Location','southeast')
title('Chisquare(20)  m = 20')%<=================================Title
xlabel('sample size')
ylabel('Power')

subplot(133)
plot(n,data(7,:),'.-','Color','g','LineWidth',1.5)
hold on 
plot(n,data(8,:),'Marker','+','Color','b')
hold on 
plot(n,data(9,:),'Marker','x')
hl = legend('MSE-RP x^2','x^2','KS');
set(hl,'Box','off','Location','southeast')
title('Chisquare(20)  m = 30')%<=================================Title
xlabel('sample size')
ylabel('Power')

end