function y=iris

% n  sepal.length sepal.width petal.length petal.width    variety

y=[
  1          5.1         3.5          1.4         0.2;     %Setosa
  2          4.9         3.0          1.4         0.2;    %Setosa
  3          4.7         3.2          1.3         0.2;     %Setosa
  4          4.6         3.1          1.5         0.2;     %Setosa
  5          5.0         3.6          1.4         0.2;     %Setosa
  6          5.4         3.9          1.7         0.4;     %Setosa
  7          4.6         3.4          1.4         0.3;     %Setosa
  8          5.0         3.4          1.5         0.2;     %Setosa
  9          4.4         2.9          1.4         0.2;     %Setosa
 10          4.9         3.1          1.5         0.1;     %Setosa
 11          5.4         3.7          1.5         0.2;     %Setosa
 12          4.8         3.4          1.6         0.2;     %Setosa
 13          4.8         3.0          1.4         0.1;     %Setosa
 14          4.3         3.0          1.1         0.1;     %Setosa
 15          5.8         4.0          1.2         0.2;     %Setosa
 16          5.7         4.4          1.5         0.4;     %Setosa
 17          5.4         3.9          1.3         0.4;    %Setosa
 18          5.1         3.5          1.4         0.3;     %Setosa
 19          5.7         3.8          1.7         0.3;     %Setosa
 20          5.1         3.8          1.5         0.3;     %Setosa
 21          5.4         3.4          1.7         0.2;     %Setosa
 22          5.1         3.7          1.5         0.4;     %Setosa
 23          4.6         3.6          1.0         0.2;     %Setosa
 24          5.1         3.3          1.7         0.5;     %Setosa
 25          4.8         3.4          1.9         0.2;     %Setosa
 26          5.0         3.0          1.6         0.2;     %Setosa
 27          5.0         3.4          1.6         0.4;     %Setosa
 28          5.2         3.5          1.5         0.2;     %Setosa
 29          5.2         3.4          1.4         0.2;     %Setosa
 30          4.7         3.2          1.6         0.2;     %Setosa
 31          4.8         3.1          1.6         0.2;     %Setosa
 32          5.4         3.4          1.5         0.4;     %Setosa
 33          5.2         4.1          1.5         0.1;     %Setosa
 34          5.5         4.2          1.4         0.2;     %Setosa
 35          4.9         3.1          1.5         0.2;     %Setosa
 36          5.0         3.2          1.2         0.2;     %Setosa
 37          5.5         3.5          1.3         0.2;     %Setosa
 38          4.9         3.6          1.4         0.1;     %Setosa
 39          4.4         3.0          1.3         0.2;     %Setosa
 40          5.1         3.4          1.5         0.2;     %Setosa
 41          5.0         3.5          1.3         0.3;     %Setosa
 42          4.5         2.3          1.3         0.3;     %Setosa
 43          4.4         3.2          1.3         0.2;     %Setosa
 44          5.0         3.5          1.6         0.6;     %Setosa
 45          5.1         3.8          1.9         0.4;     %Setosa
 46          4.8         3.0          1.4         0.3;     %Setosa
 47          5.1         3.8          1.6         0.2;     %Setosa
 48          4.6         3.2          1.4         0.2;     %Setosa
 49          5.3         3.7          1.5         0.2;     %Setosa
 50          5.0         3.3          1.4         0.2;     %Setosa
 51          7.0         3.2          4.7         1.4;  %Versicolor
 52          6.4         3.2          4.5         1.5; %Versicolor
 53          6.9         3.1          4.9         1.5; %Versicolor
 54          5.5         2.3          4.0         1.3; %Versicolor
 55          6.5         2.8          4.6         1.5; %Versicolor
 56          5.7         2.8          4.5         1.3; %Versicolor
 57          6.3         3.3          4.7         1.6; %Versicolor
 58          4.9         2.4          3.3         1.0; %Versicolor
 59          6.6         2.9          4.6         1.3; %Versicolor
 60          5.2         2.7          3.9         1.4; %Versicolor
 61          5.0         2.0          3.5         1.0; %Versicolor
 62          5.9         3.0          4.2         1.5; %Versicolor
 63          6.0         2.2          4.0         1.0; %Versicolor
 64          6.1         2.9          4.7         1.4; %Versicolor
 65          5.6         2.9          3.6         1.3; %Versicolor
 66          6.7         3.1          4.4         1.4; %Versicolor
 67          5.6         3.0          4.5         1.5; %Versicolor
 68          5.8         2.7          4.1         1.0; %Versicolor
 69          6.2         2.2          4.5         1.5; %Versicolor
 70          5.6         2.5          3.9         1.1; %Versicolor
 71          5.9         3.2          4.8         1.8; %Versicolor
 72          6.1         2.8          4.0         1.3; %Versicolor
 73          6.3         2.5          4.9         1.5; %Versicolor
 74          6.1         2.8          4.7         1.2; %Versicolor
 75          6.4         2.9          4.3         1.3; %Versicolor
 76          6.6         3.0          4.4         1.4; %Versicolor
 77          6.8         2.8          4.8         1.4; %Versicolor
 78          6.7         3.0          5.0         1.7; %Versicolor
 79          6.0         2.9          4.5         1.5; %Versicolor
 80          5.7         2.6          3.5         1.0; %Versicolor
 81          5.5         2.4          3.8         1.1; %Versicolor
 82          5.5         2.4          3.7         1.0; %Versicolor
 83          5.8         2.7          3.9         1.2; %Versicolor
 84          6.0         2.7          5.1         1.6; %Versicolor
 85          5.4         3.0          4.5         1.5; %Versicolor
 86          6.0         3.4          4.5         1.6; %Versicolor
 87          6.7         3.1          4.7         1.5; %Versicolor
 88          6.3         2.3          4.4         1.3; %Versicolor
 89          5.6         3.0          4.1         1.3; %Versicolor
 90          5.5         2.5          4.0         1.3; %Versicolor
 91          5.5         2.6          4.4         1.2; %Versicolor
 92          6.1         3.0          4.6         1.4; %Versicolor
 93          5.8         2.6          4.0         1.2; %Versicolor
 94          5.0         2.3          3.3         1.0; %Versicolor
 95          5.6         2.7          4.2         1.3; %Versicolor
 96          5.7         3.0          4.2         1.2; %Versicolor
 97          5.7         2.9          4.2         1.3; %Versicolor
 98          6.2         2.9          4.3         1.3; %Versicolor
 99          5.1         2.5          3.0         1.1; %Versicolor
100          5.7         2.8          4.1         1.3; %Versicolor
101          6.3         3.3          6.0         2.5; % Virginica
102          5.8         2.7          5.1         1.9; % Virginica
103          7.1         3.0          5.9         2.1; % Virginica
104          6.3         2.9          5.6         1.8; % Virginica
105          6.5         3.0          5.8         2.2; % Virginica
106          7.6         3.0          6.6         2.1; % Virginica
107          4.9         2.5          4.5         1.7; % Virginica
108          7.3         2.9          6.3         1.8; % Virginica
109          6.7         2.5          5.8         1.8; % Virginica
110          7.2         3.6          6.1         2.5;  %Virginica
111          6.5         3.2          5.1         2.0  %Virginica
112          6.4         2.7          5.3         1.9  %Virginica
113          6.8         3.0          5.5         2.1;  %Virginica
114          5.7         2.5          5.0         2.0;  %Virginica
115          5.8         2.8          5.1         2.4;  %Virginica
116          6.4         3.2          5.3         2.3;  %Virginica
117          6.5         3.0          5.5         1.8;  %Virginica
118          7.7         3.8          6.7         2.2;  %Virginica
119          7.7         2.6          6.9         2.3;  %Virginica
120          6.0         2.2          5.0         1.5;  %Virginica
121          6.9         3.2          5.7         2.3;  %Virginica
122          5.6         2.8          4.9         2.0;  %Virginica
123          7.7         2.8          6.7         2.0;  %Virginica
124          6.3         2.7          4.9         1.8;  %Virginica
125          6.7         3.3          5.7         2.1;  %Virginica
126          7.2         3.2          6.0         1.8;  %Virginica
127          6.2         2.8          4.8         1.8;  %Virginica
128          6.1         3.0          4.9         1.8;  %Virginica
129          6.4         2.8          5.6         2.1;  %Virginica
130          7.2         3.0          5.8         1.6;  %Virginica
131          7.4         2.8          6.1         1.9;  %Virginica
132          7.9         3.8          6.4         2.0;  %Virginica
133          6.4         2.8          5.6         2.2;  %Virginica
134          6.3         2.8          5.1         1.5;  %Virginica
135          6.1         2.6          5.6         1.4;  %Virginica
136          7.7         3.0          6.1         2.3;  %Virginica
137          6.3         3.4          5.6         2.4;  %Virginica
138          6.4         3.1          5.5         1.8;  %Virginica
139          6.0         3.0          4.8         1.8; % Virginica
140          6.9         3.1          5.4         2.1; % Virginica
141          6.7         3.1          5.6         2.4;  %Virginica
142          6.9         3.1          5.1         2.3;  %Virginica
143          5.8         2.7          5.1         1.9;  %Virginica
144          6.8         3.2          5.9         2.3;  %Virginica
145          6.7         3.3          5.7         2.5;  %Virginica
146          6.7         3.0          5.2         2.3;  %Virginica
147          6.3         2.5          5.0         1.9;  %Virginica
148          6.5         3.0          5.2         2.0;  %Virginica
149          6.2         3.4          5.4         2.3;  %Virginica
150          5.9         3.0          5.1         1.8];  %Virginica

                                                       
                                                       
