function result = example(data,k)
% k = 15;
normal_RP_data = xlsread('C:\ѧϰ\FYP\Code\һԪ��̬�ֲ�����\Normal.xlsx',1);
alpha = 0.05;
m = 2*k;
method_1_x_square = chi2inv(1-alpha,m-3);
method_2_x_square = chi2inv(1-alpha,m-2);
method_3_x_square = chi2inv(1-alpha,m-1);
normal_RP = normal_RP_data(m,1:m/2);
t_RP =  xlsread('C:\ѧϰ\FYP\��һƪ����\Simulation\t_RP_m30.xlsx',1);
random_number = data;
n = length(random_number);
miu = mean(random_number);
sigma = std(random_number);
normal_RP_method_1 = miu+sigma.*normal_RP;

random_number_method_2 = zeros((n-1),1);
for j = 1:(n-1)
    random_number_method_2(j) = (sum(random_number(1:j))-j*random_number(j+1))/sqrt(j*(j+1));
end

sigma_method_2 = std(random_number_method_2);
normal_RP_method_2 = sqrt(sigma_method_2).*normal_RP;

t_random_number = random_number;
t_miu = mean(t_random_number);
t_sigma = std(t_random_number);
random_number_method_3 = (t_random_number-t_miu)/t_sigma;
t_RP_method_3 = t_RP; %t�ֲ������� ��Run�в���������


I_1 = MSE_RP_Method_1(random_number,normal_RP_method_1,n,k,method_1_x_square,miu,sigma);%MSE-RP Chi-square test
I_2 = MSE_RP_Method_2(random_number_method_2,normal_RP_method_2,n-1,k,method_2_x_square,sigma_method_2);%MSE-RP Chi-square test
I_3 = MSE_RP_Method_3(random_number_method_3,t_RP_method_3,n,k,method_3_x_square);%MSE-RP Chi-square test
I_4 = Original_Chi_Method(random_number,n,k,method_1_x_square);%Original Chi-square test
result = [I_1,I_2,I_3,I_4];

end