%�ⷽ�̷�������MSE������
function f = MSERPLA(m,b)
%��ʼֵ
epsilon=10^(-6);
L=fix(m/2);
x=zeros(m,m);
p=zeros(m,m);
x(1,1)=0;
x(2,1)=1;
x(3,1)=2;

%����ż���еĴ�����
for i = 2*(2:L)
l=i/2;
x(i,1)=1/(l+1)*x(2*(l-1),1);
LP=0;
RP=x(2*(l-1),1);  
e=1;
syms xt;
syms f;
syms ft;
%ѭ�������С��epsilonΪֹ
while (e>=epsilon)
x1 = x(i,1);
% ����x2
syms x2;
f=(x1-b)*(lacdf(b,(x1+x2)/2)-lacdf(b,0))+b*(x1+x2)/2*lapdf(b,(x1+x2)/2);
f1=matlabFunction(f,'Vars',x2);
x2=fzero(f1,[x1 20]);
x(i,2)=x2;
%����x3����xm
if (l>=3)
for j=3:l
f=@(xm)(x(i,j-1)-b)*(lacdf(b,1/2*(x(i,j-1)+xm))-lacdf(b,1/2*(x(i,j-2)+x(i,j-1))))-b*(1/2*(x(i,j-2)+x(i,j-1))*lapdf(b,1/2*(x(i,j-2)+x(i,j-1)))-1/2*(x(i,j-1)+xm)*lapdf(b,1/2*(x(i,j-1)+xm)));
xm=fzero(f,[x(i,j-1) 20]);
x(i,j)=xm;
end
end
%����xm*
ft=@(xt)(xt-b)*(1-lacdf(b,1/2*(x(i,l-1)+xt)))-b*(1/2*(x(i,l-1)+xt)*lapdf(b,1/2*(x(i,l-1)+xt)));
xt=fzero(ft,[x(i,l-1) 20]);
e=abs(x(i,l)-xt);
%����LP,RP and x1��ֵ
if (x(i,l)<(xt+epsilon))
LP=x(i,1);
x(i,1)=1/2*(LP+RP);
elseif (x(i,l)>(xt-epsilon))
RP=x(i,1);
x(i,1)=1/2*(LP+RP);
end
end

%�������
p(i,2)=lacdf(b,(x(i,1)+x(i,2))/2)-lacdf(b,0);
for j=3:l
    p(i,j)=lacdf(b,(x(i,j-1)+x(i,j))/2)-lacdf(b,(x(i,j-1)+x(i,j-2))/2);
end
p(i,l+1)=lacdf(b,inf)-lacdf(b,(x(i,l-1)+x(i,l))/2);

end

%���������еĴ�����
for i = 2*(2:L)+1
l=(i-1)/2;
x(i,1)=1/(l+1)*x(2*(l-1)+1,1);
LP=0;
RP=x(2*(l-1)+1,1);  
e=1;
syms xt;
syms f;
syms ft;
%ѭ�������С��epsilonΪֹ
while (e>=epsilon)
x1 = x(i,1);
% calculate value of x2
syms x2;
f=(x1-b)*(lacdf(b,1/2*(x1+x2))-lacdf(b,1/2*x1))-b*(1/2*x1*lapdf(b,1/2*x1)-1/2*(x1+x2)*lapdf(b,1/2*(x1+x2)));
f1=matlabFunction(f,'Vars',x2);
x2=fzero(f1,[x1 20]);
x(i,2)=x2;
%calculate value of x3����xm
if (l>=3)
for j=3:l
f=@(xm)(x(i,j-1)-b)*(lacdf(b,1/2*(x(i,j-1)+xm))-lacdf(b,1/2*(x(i,j-2)+x(i,j-1))))-b*(1/2*(x(i,j-2)+x(i,j-1))*lapdf(b,1/2*(x(i,j-2)+x(i,j-1)))-1/2*(x(i,j-1)+xm)*lapdf(b,1/2*(x(i,j-1)+xm)));
xm=fzero(f,[x(i,j-1) 20]);
x(i,j)=xm;
end
end
%calculate x*
ft=@(xt)(xt-b)*(1-lacdf(b,1/2*(x(i,l-1)+xt)))-b*(1/2*(x(i,l-1)+xt)*lapdf(b,1/2*(x(i,l-1)+xt)));
xt=fzero(ft,[x(i,l-1) 20]);
e=abs(x(i,l)-xt);
%update value of LP,RP and x1 
if (x(i,l)<(xt+epsilon))
LP=x(i,1);
x(i,1)=1/2*(LP+RP);
elseif (x(i,l)>(xt-epsilon))
RP=x(i,1);
x(i,1)=1/2*(LP+RP);
end
end
p(i,1)=2*(lacdf(b,x(i,1)/2)-lacdf(b,0));
p(i,2)=lacdf(b,(x(i,1)+x(i,2))/2)-lacdf(b,x(i,1)/2);
for j=3:(l)
    p(i,j)=lacdf(b,(x(i,j-1)+x(i,j))/2)-lacdf(b,(x(i,j-2)+x(i,j-1))/2);
end
p(i,l+1)=lacdf(b,inf)-lacdf(b,(x(i,l-1)+x(i,l))/2);
end
p(1,1)=1.0000; 
p(2,2)=0.500000;
p(3,1)=2*(lacdf(b,x(3,1)/2)-lacdf(b,0));
p(3,2)=lacdf(b,inf)-lacdf(b,x(3,1)/2);

rp=x(1:m,1:L);
if mod(m,2)~=0
prob=p(1:m,1:L+1);
elseif mod(m,2)==0
prob=p(1:m,1:L+1);
end
f = rp;
end

function f=lapdf(b,x)
f=1/(2*b)*exp(-x/b);
end

function f=lacdf(b,x)
f=1-1/2*exp(-x/b);
end



