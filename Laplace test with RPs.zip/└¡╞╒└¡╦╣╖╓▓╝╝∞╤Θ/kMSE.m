function [X,P]=kMSE(epsilon,N)
tic
l1=fix(N/2);
% ��ͼpdf
% x=-7:0.01:7; 
% y=exp(-x)./((1+exp(-x)).^2);
% plot(x, y);
% grid on;
% axis([-7 7 0 0.3])
% title('RP for standard logistic distribution(MSE)');
% ylabel('pdf');
% xlabel('x');
% hold on
%��ͼcdf
% x=-7:0.01:7; 
% y=1./(1+exp(-x));
% plot(x, y);
% grid on;
% axis([-7 7 0 1])
% title('RP for standard logistic distribution');
% ylabel('cdf');
% xlabel('x');
% hold on
% tic
X1=zeros(l1,l1);%��ʾRP�ľ�������������ʱl��ȡֵ�������Ǿ���
P1=zeros(l1,l1);%�����ʵľ�������������ʱl��ȡֵ�������Ǿ���P��Xһһ��Ӧ
MSE1=zeros(l1,1);
X1(1,1)=2*log(2);
P1(1,1)=0.5;
syms f ff x;
f=exp(-x)./((1+exp(-x)).^2);
ff=(x-X1(1,1)).^2.*f;
MSE1(1)=2*int(ff,x,0,inf);
for i=2:l1 %���������У�����ÿһ��lȡֵ��Ӧ�Ĵ�����
LP=0;
RP=X1((i-1),1);
X1(i,1)=1/(i+1)*X1((i-1),1);
%����whileѭ���ĳ�ʼֵ
x_star=1; 
syms f x;
f=exp(-x)./((1+exp(-x)).^2);
while(abs(X1(i,i)-x_star)>=epsilon)
%x2
syms x2;
        x1=X1(i,1);        
        f1=(1/(1+exp(-0.5*(x1+x2)))-(1/(1+exp(-0))))*x1-int(x*f,x,0,0.5*(x1+x2));
        temp=matlabFunction(f1,'Vars',x2);
        x2=fzero(temp,[x1 10]);
        X1(i,2)=x2;
for j=3:i
%x3
syms x3;
        x1=X1(i,(j-2));
        x2=X1(i,(j-1));
        f1=(1./(1+exp(-0.5*(x2+x3)))-1./(1+exp(-0.5*(x1+x2))))*x2-int(x*f,x,0.5*(x1+x2),0.5*(x2+x3));
        temp=matlabFunction(f1,'Vars',x3);
        x3=fzero(temp,[x2 10]);
        X1(i,j)=x3;
end
%x_star,������֤
syms x_star;
        x2=X1(i,(i-1));     
        f2=(1-1/(1+exp(-0.5*(x2+x_star))))*x_star-int(x*f,x,0.5*(x2+x_star),inf);
        temp2=matlabFunction(f2,'Vars',x_star);
        x_star=fzero(temp2,[x2 10]);
%����
        if(x_star+epsilon>X1(i,i))
            LP= X1(i,1);
            X1(i,1)=0.5*(LP+RP);
        else if(x_star-epsilon< X1(i,i))
                RP= X1(i,1);
                X1(i,1)=0.5*(LP+RP);
            end
        end    
end
P1(i,1)=1/(1+exp(-0.5*(X1(i,1)+X1(i,2))))-1/(1+exp(-0));
for k=2:(i-1)
P1(i,k)=1/(1+exp(-0.5*(X1(i,k)+X1(i,(k+1)))))-1/(1+exp(-0.5*(X1(i,(k-1))+X1(i,k))));
end
P1(i,i)=1-1/(1+exp(-0.5*(X1(i,(i-1))+X1(i,i))));
syms ff x;
ff=(x-X1(i,1)).^2.*f;
MSE1(i)=2*int(ff,x,0,0.5*(X1(i,1)+X1(i,2)));
for q=2:(i-1)
ff=(x-X1(i,q)).^2.*f;
MSE1(i)=MSE1(i)+2*int(ff,x,0.5*(X1(i,q)+X1(i,(q-1))),0.5*(X1(i,q)+X1(i,(q+1))));
end
ff=(x-X1(i,i)).^2.*f;
MSE1(i)=MSE1(i)+2*int(ff,x,0.5*(X1(i,(i-1))+X1(i,i)),inf);
end
MSE1=MSE1/(pi^2/3);
%��ͼ
% for m=1:l1
% plot([sort(-X1(m,1:m)),X1(m,1:m)],cumsum([sort(P1(m,1:m)),P1(m,1:m)]));
% hold on
% end
if(mod(N,2)==0)
    plot([sort(-X1(l1,1:l1)),X1(l1,1:l1)],cumsum([sort(P1(l1,1:l1)),P1(l1,1:l1)]));
end
% �����������������ż������ĺϲ�
list=[];
list(:,1)=2*(1:l1);
Xeven=[list,MSE1,X1];
list(:,2)=nan;
Peven=[list,P1];
%������������
l2=fix((N-1)/2);
X2=zeros(l2,l1);%��ʾRP�ľ�������������ʱl2��ȡֵ�������Ǿ���
P2=zeros(l2,(l1+1));%�����ʵľ�������������ʱl2��ȡֵ�������Ǿ���P��Xһһ��Ӧ
MSE2=zeros(l2,1);
%�����ʼֵ
syms x f 
f=exp(-x)./((1+exp(-x)).^2);
syms ff x1
ff=int((x-x1)*f,x,0.5*x1,inf);
temp=matlabFunction(ff,'Vars',x1);
x1=fzero(temp,[0,7]);
X2(1,1)=x1;
P2(1,1)=2*(1/(1+exp(-0.5*X2(1,1)))-1/(1+exp(0)));
P2(1,2)=1-1/(1+exp(-0.5*X2(1,1)));
syms ff fm x;
ff=(x-X2(1,1)).^2.*f;
fm=(x-0).^2.*f;
MSE2(1)=2*(int(ff,x,0.5*X2(1,1),inf)+int(fm,x,0,0.5*X2(1,1)));
for i=2:l2 %���������У�����ÿһ��l2ȡֵ��Ӧ�Ĵ�����
LP=0;
RP=X2((i-1),1);
X2(i,1)=1/(i+1)*X2((i-1),1);
%����whileѭ���ĳ�ʼֵ
x_star=1; 
syms f x;
f=exp(-x)./((1+exp(-x)).^2);
while(abs(X2(i,i)-x_star)>=epsilon)
%x2
syms x2;
        x1=X2(i,1);        
        f1=(1/(1+exp(-0.5*(x1+x2)))-1/(1+exp(-0.5*x1)))*x1-int(x*f,x,0.5*x1,0.5*(x1+x2));
        temp=matlabFunction(f1,'Vars',x2);
        x2=fzero(temp,[x1 10]);
        X2(i,2)=x2;
for j=3:i
%x3
syms x3;
        x1=X2(i,(j-2));
        x2=X2(i,(j-1));
        f1=(1/(1+exp(-0.5*(x2+x3)))-1/(1+exp(-0.5*(x1+x2))))*x2-int(x*f,x,0.5*(x1+x2),0.5*(x2+x3));
        temp=matlabFunction(f1,'Vars',x3);
        x3=fzero(temp,[x2 10]);
        X2(i,j)=x3;
end
%x_star,������֤
syms x_star;
        x2=X2(i,(i-1));     
        f2=(1-1/(1+exp(-0.5*(x2+x_star))))*x_star-int(x*f,x,0.5*(x2+x_star),inf);
        temp2=matlabFunction(f2,'Vars',x_star);
        x_star=fzero(temp2,[x2 10]);
%����
        if(x_star+epsilon>X2(i,i))
            LP= X2(i,1);
            X2(i,1)=0.5*(LP+RP);
        else if(x_star-epsilon< X2(i,i))
                RP= X2(i,1);
                X2(i,1)=0.5*(LP+RP);
            end
        end    
end


P2(i,1)=2*(1/(1+exp(-0.5*(X2(i,1))))-1/(1+exp(-0)));
P2(i,2)=1/(1+exp(-0.5*(X2(i,1)+X2(i,2))))-1/(1+exp(-0.5*(X2(i,1))));
for k=3:i
P2(i,k)=1/(1+exp(-0.5*(X2(i,k)+X2(i,(k-1)))))-1/(1+exp(-0.5*(X2(i,(k-1))+X2(i,(k-2)))));
end
P2(i,(i+1))=1-1/(1+exp(-0.5*(X2(i,(i-1))+X2(i,i))));
syms ff fm;
ff=(x-X2(i,1)).^2.*f;
fm=(x-0).^2.*f;
MSE2(i)=2*(int(ff,x,0.5*X2(i,1),0.5*(X2(i,1)+X2(i,2)))+int(fm,x,0,0.5*X2(i,1)));
for q=2:(i-1)
ff=(x-X2(i,q)).^2.*f;
MSE2(i)=MSE2(i)+2*int(ff,x,0.5*(X2(i,q)+X2(i,(q-1))),0.5*(X2(i,q)+X2(i,(q+1))));
end
ff=(x-X2(i,i)).^2.*f;
MSE2(i)=MSE2(i)+2*int(ff,x,0.5*(X2(i,(i-1))+X2(i,i)),inf);
end
MSE2=MSE2/(pi^2/3);



% ��ͼ
% for m=1:l2
% plot([sort(-X2(m,1:m)),0,X2(m,1:m)],cumsum([sort(P2(m,2:(m+1))),P2(m,1:(m+1))]));
% hold on
% end
if(mod(N,2)~=0)
    plot([sort(-X2(l2,1:l2)),0,X2(l2,1:l2)],cumsum([sort(P2(l2,2:(l2+1))),P2(l2,1:(l2+1))]));
end
list=[];
list(:,1)=2*(1:l2)+1;
Xodd=[list,MSE2,X2];
Podd=[list,P2];
X=[Xeven;Xodd];
P=[Peven;Podd];
Xeven
%X=sortrows(X,1);
%P=sortrows(P,1);
toc
end