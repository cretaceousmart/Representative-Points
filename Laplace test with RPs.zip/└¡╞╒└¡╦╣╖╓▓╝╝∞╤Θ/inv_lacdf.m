function f = inv_lacdf(p,miu,b) 
f = miu-b.*sign(p-0.5).*log(1-2.*abs(p-0.5));
end