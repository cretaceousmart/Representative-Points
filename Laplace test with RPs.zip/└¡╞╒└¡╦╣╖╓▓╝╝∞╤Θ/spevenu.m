% Subroutines for generating the uniform distr. on the unit sphere of
% R^p, where p is an even number
% x is nxp matrix

function x=spevenu(n,p)
%C=glp(n,vec);  % length of vec is s
C=rand(n,p-1);
[n,s]=size(C);
p1=(s+1)/2;
power=ones(n,1)*[1:p1-1];
power=1 ./ power;
Cp=C(:,1:p1-1).^power;
if p1==2
Hp=Cp(:,1);
else
Cp=rot90(Cp);  % counterclock 90 degree of a matrix
Cp=cumprod(Cp); % cumulative products for every columns
Hp=rot90(Cp,3);
end;
DH1=[zeros(n,1) Hp];
DH2=[Hp ones(n,1)];
D=sqrt(DH2-DH1);
G=2*pi*C(:,p1-1+[1:p1]);
odd=2*[1:p1]-1;
even=2*[1:p1];
x=zeros(n,2*p1);
x(:,odd)=D(:,1:p1).*cos(G);
x(:,even)=D(:,1:p1).*sin(G);



