function F = lapdf(X,miu,b)
F = (1./(2.*b)).*exp(-(abs(X-miu)./(b)));
end
