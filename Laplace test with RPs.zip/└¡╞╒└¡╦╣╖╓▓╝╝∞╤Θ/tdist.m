function y=tdist(n,p,m)
% y is an nxp matrix
% m is the parameter of p-dim t-distr., if using the following betadist
% subroutine, m should be an integer.
% This program is used to generate p-dim t-distribution.
%the density is c_p(1+x'*x/m)^(-(m+p)/2));

%v=betadist(n,1,p/2,m/2);
v=betarnd(p/2,m/2,n,1);
r=sqrt(m*v./(1-v));
uniform=spu(n,p); %the unform distr. on the unit sphere of R^p:   n by p
                                                                 % matrix
y=uniform.*(r*ones(1,p));

