function y=tlossfun(X,n)

m=length(X);
syms x;
c(1)=vpa(int((X(1)-x)^2*gamma((n+1)/2)*(1+x^2/n)^(-(n+1)/2)/(sqrt(n*pi)*gamma(n/2)),-inf,(X(1)+X(2))/2));
for i=2:m-1
    c(i)=vpa(int((X(i)-x)^2*gamma((n+1)/2)*(1+x^2/n)^(-(n+1)/2)/(sqrt(n*pi)*gamma(n/2)),(X(i-1)+X(i))/2,(X(i)+X(i+1))/2));
end
c(m)=vpa(int((X(m)-x)^2*gamma((n+1)/2)*(1+x^2/n)^(-(n+1)/2)/(sqrt(n*pi)*gamma(n/2)),(X(m-1)+X(m))/2,inf));
c;
y=sum(c);
end

