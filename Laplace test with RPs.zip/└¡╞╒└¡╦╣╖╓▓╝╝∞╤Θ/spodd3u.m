% a subroutine for generating uniform distr. on the unit sphere (ball surface)
% of 3-dimensional space, R^3

function x=spodd3u(n)  %x is nx3 matrix
C=rand(n,2);
a=2*sqrt(C(:,1).*(1-C(:,1)));
b=2*pi*C(:,2);
x=zeros(n,3);
x(:,1)=1-2*C(:,1);
x(:,2)=a.*cos(b);
x(:,3)=a.*sin(b);




