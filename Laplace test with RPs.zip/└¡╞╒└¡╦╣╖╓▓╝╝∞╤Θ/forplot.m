clear;clc;

%Beta ������̬�ֲ�
for i = 3:5
beta = i;
r = 1;
x = -10:0.1:10;
fx = beta/(2*gamma(beta))*exp(-1*(abs(x)).^beta);
plot(x,fx)
hold on 
end
title('��-generalized normal distribution with r = 1')
legend('��=3','��=4','��=5')
fx1 = 2*normpdf(x);
plot(x,fx1)


x = -10:0.1:10;
pd_1 = pdf('Weibull',x,3,1);
plot(x,pd_1)
hold on 
pd_2 = tpdf(x,10);
plot(x,pd_2)
hold on 
pd_3 = tpdf(x,20);
plot(x,pd_3)
pd_4 = normpdf(x);
plot(x,pd_4)
legend({'t(5)','t(10)','t(20)','N(0,1)'})











data = xlsread('C:\ѧϰ\FYP\Code\һԪ��̬�ֲ�����\�½��\t(5).xlsx',1);
n = 50:50:500;

subplot(131)
% for i = 1:6
%    plot(n,data(i,:),'Marker',fuhao(i))
%    hold on 
% end


plot(n,data(1,:),'Marker','.')
axis([30 300 0 1])
hold on 
plot(n,data(2,:),'Marker','+')
hold on 
plot(n,data(3,:),'Marker','x')
hold on 
plot(n,data(4,:),'.-','LineWidth',1.5,'Color','g')
hold on 
set(gca,'xtick',30:30:300);
% set(gca,'ytick',0:0.1:1);
hl = legend('MSE-RP Chi-square Method_1','MSE-RP Chi-square Method_2','MSE-RP Chi-square Method_3','Original Chi-square Method');
set(hl,'Box','off','Location','southeast')
title('Weibull-E(Weibull)      m = 10')
xlabel('sample size')
ylabel('Power')


subplot(132)

plot(n,data(5,:),'Marker','.')
axis([30 300 0 1])
hold on 
plot(n,data(6,:),'Marker','+')
hold on 
plot(n,data(7,:),'Marker','x')
hold on 
plot(n,data(8,:),'.-','LineWidth',1.5,'Color','g')
hold on 
set(gca,'xtick',30:30:300);
% set(gca,'ytick',0:0.1:1);
hl = legend('MSE-RP Chi-square Method_1','MSE-RP Chi-square Method_2','MSE-RP Chi-square Method_3','Original Chi-square Method');
set(hl,'Box','off','Location','southeast')
title('Weibull-E(Weibull)      m = 20')
xlabel('sample size')
ylabel('Power')


subplot(133)

plot(n,data(9,:),'Marker','.')
axis([50 500 0 1])
hold on 
plot(n,data(10,:),'Marker','+')
hold on 
plot(n,data(11,:),'Marker','x')
hold on 
plot(n,data(12,:),'.-','LineWidth',1.5,'Color','g')
hold on 
set(gca,'xtick',50:50:500);
% set(gca,'ytick',0:0.1:1);
hl = legend('MSE-RP Chi-square Method_1','MSE-RP Chi-square Method_2','MSE-RP Chi-square Method_3','Original Chi-square Method');
set(hl,'Box','off','Location','southeast')
title('Weibull-E(Weibull)      m = 30')
xlabel('sample size')
ylabel('Power')

data = xlsread('C:\ѧϰ\FYP\Code\һԪ��̬�ֲ�����\�½��\Beta������̬r1 beta5.xlsx',1);
data = xlsread('C:\ѧϰ\FYP\��һƪ����\Simulation\cauchy.xlsx',1);
n = 50:50:500;



%��һ�����

data = xlsread('C:\ѧϰ\FYP\��һƪ����\Simulation\error1_0.05.xlsx',1);
n = 30:30:300;
subplot(131)
m10_data = data(1:4,:);
plot(n,m10_data(1,:),'.-','Color','g','LineWidth',1.5)
hold on 
plot(n,m10_data(2,:),'Marker','+','Color','b')
hold on 
plot(n,m10_data(3,:),'Marker','x')
hold on 
plot(n,m10_data(4,:),'.-','LineWidth',1.5,'Color','r')
hold on 
set(gca,'xtick',30:30:300);
% set(gca,'ytick',0:0.1:1);
hl = legend('MSE-RP x^2_1','MSE-RP x^2_2','MSE-RP x^2_3','x^2');
set(hl,'Box','off','Location','southeast')
title('N(3,2) m = 10')
xlabel('sample size')
ylabel('Type I Error')

subplot(132)
m20_data = data(5:8,:);
plot(n,m20_data(1,:),'.-','Color','g','LineWidth',1.5)
hold on 
plot(n,m20_data(2,:),'Marker','+','Color','b')
hold on 
plot(n,m20_data(3,:),'Marker','x')
hold on 
plot(n,m20_data(4,:),'.-','LineWidth',1.5,'Color','r')
hold on 
set(gca,'xtick',30:30:300);
% set(gca,'ytick',0:0.1:1);
hl = legend('MSE-RP x^2_1','MSE-RP x^2_2','MSE-RP x^2_3','x^2');
set(hl,'Box','off','Location','southeast')
title('N(3,2) m = 20')
xlabel('sample size')
ylabel('Type I Error')

subplot(133)
m30_data = data(9:12,:);
plot(n,m30_data(1,:),'.-','Color','g','LineWidth',1.5)
hold on 
plot(n,m30_data(2,:),'Marker','+','Color','b')
hold on 
plot(n,m30_data(3,:),'Marker','x')
hold on 
plot(n,m30_data(4,:),'.-','LineWidth',1.5,'Color','r')
hold on 
set(gca,'xtick',30:30:300);
% set(gca,'ytick',0:0.1:1);
hl = legend('MSE-RP x^2_1','MSE-RP x^2_2','MSE-RP x^2_3','x^2');
set(hl,'Box','off','Location','southeast')
title('N(3,2) m = 30')
xlabel('sample size')
ylabel('Type I Error')












%˫ͼ
t_data = xlsread('C:\ѧϰ\FYP\��һƪ����\Simulation\new Shift Chisquare.xlsx',1);
la_data = xlsread('C:\ѧϰ\FYP\��һƪ����\Simulation\new LogNormal.xlsx',1);

subplot(231)
m10_data = t_data(1:4,:);
data = m10_data;
plot(n,data(1,:),'*-','Color','g','LineWidth',1.5)
axis([10 100 0 1])
hold on 
plot(n,data(2,:),'Marker','*-','Color','b')
hold on 
plot(n,data(3,:),'Marker','*-')
hold on 
plot(n,data(4,:),'*-','LineWidth',1.5,'Color','r')
hold on 
set(gca,'xtick',10:10:100);
% set(gca,'ytick',0:0.1:1);
hl = legend('MSE-RP Chi-square Method_1','MSE-RP Chi-square Method_2','MSE-RP Chi-square Method_3','Original Chi-square Method');
set(hl,'Box','off','Location','southeast')
title('Shift Chisquare  m = 10')
xlabel('sample size')
ylabel('Power')

subplot(232)
m10_data = t_data(5:8,:);
data = m10_data;
plot(n,data(1,:),'.-','Color','g','LineWidth',1.5)
axis([10 100 0 1])
hold on 
plot(n,data(2,:),'Marker','+','Color','b')
hold on 
plot(n,data(3,:),'Marker','x')
hold on 
plot(n,data(4,:),'.-','LineWidth',1.5,'Color','r')
hold on 
set(gca,'xtick',10:10:100);
% set(gca,'ytick',0:0.1:1);
hl = legend('MSE-RP Chi-square Method_1','MSE-RP Chi-square Method_2','MSE-RP Chi-square Method_3','Original Chi-square Method');
set(hl,'Box','off','Location','southeast')
title('Shift Chisquare  m = 20')
xlabel('sample size')
ylabel('Power')

subplot(233)
m10_data = t_data(9:12,:);
data = m10_data;
plot(n,data(1,:),'.-','Color','g','LineWidth',1.5)
axis([10 100 0 1])
hold on 
plot(n,data(2,:),'Marker','+','Color','b')
hold on 
plot(n,data(3,:),'Marker','x')
hold on 
plot(n,data(4,:),'.-','LineWidth',1.5,'Color','r')
hold on 
set(gca,'xtick',10:10:100);
% set(gca,'ytick',0:0.1:1);
hl = legend('MSE-RP Chi-square Method_1','MSE-RP Chi-square Method_2','MSE-RP Chi-square Method_3','Original Chi-square Method');
set(hl,'Box','off','Location','southeast')
title('Shift Chisquare  m = 30')
xlabel('sample size')
ylabel('Power')


subplot(234)
m10_data = la_data(1:4,:);
data = m10_data;
plot(n,data(1,:),'.-','Color','g','LineWidth',1.5)
axis([10 100 0 1])
hold on 
plot(n,data(2,:),'Marker','+','Color','b')
hold on 
plot(n,data(3,:),'Marker','x')
hold on 
plot(n,data(4,:),'.-','LineWidth',1.5,'Color','r')
hold on 
set(gca,'xtick',10:10:100);
% set(gca,'ytick',0:0.1:1);
hl = legend('MSE-RP Chi-square Method_1','MSE-RP Chi-square Method_2','MSE-RP Chi-square Method_3','Original Chi-square Method');
set(hl,'Box','off','Location','southeast')
title('LogNormal  m = 10')
xlabel('sample size')
ylabel('Power')

subplot(235)
m10_data = la_data(5:8,:);
data = m10_data;
plot(n,data(1,:),'.-','Color','g','LineWidth',1.5)
axis([10 100 0 1])
hold on 
plot(n,data(2,:),'Marker','+','Color','b')
hold on 
plot(n,data(3,:),'Marker','x')
hold on 
plot(n,data(4,:),'.-','LineWidth',1.5,'Color','r')
hold on 
set(gca,'xtick',10:10:100);
% set(gca,'ytick',0:0.1:1);
hl = legend('MSE-RP Chi-square Method_1','MSE-RP Chi-square Method_2','MSE-RP Chi-square Method_3','Original Chi-square Method');
set(hl,'Box','off','Location','southeast')
title('LogNormal  m = =20')
xlabel('sample size')
ylabel('Power')

subplot(236)
m10_data = la_data(9:12,:);
data = m10_data;
plot(n,data(1,:),'.-','Color','g','LineWidth',1.5)
axis([10 100 0 1])
hold on 
plot(n,data(2,:),'Marker','+','Color','b')
hold on 
plot(n,data(3,:),'Marker','x')
hold on 
plot(n,data(4,:),'.-','LineWidth',1.5,'Color','r')
hold on 
set(gca,'xtick',10:10:100);
% set(gca,'ytick',0:0.1:1);
hl = legend('MSE-RP Chi-square Method_1','MSE-RP Chi-square Method_2','MSE-RP Chi-square Method_3','Original Chi-square Method');
set(hl,'Box','off','Location','southeast')
title('LogNormal  m = 30')
xlabel('sample size')
ylabel('Power')
%=====================================================================================





%��ͼ
t_data = xlsread('D:\ѧϰ\FYP\Code\������˹�ֲ�����\result\Cauchy.xlsx',1);
la_data = xlsread('D:\ѧϰ\FYP\Code\������˹�ֲ�����\result\double.xlsx',1);
de_data = xlsread('D:\ѧϰ\FYP\Code\������˹�ֲ�����\result\t(5).xlsx',1);


n = 100:100:1500;
subplot(331)
m10_data = t_data(1:3,:);
data = m10_data;
plot(n,data(1,:),'.-','Color','g','LineWidth',1.5)
axis([100 1000 0 1])
hold on 
plot(n,data(2,:),'Marker','+','Color','b')
hold on 
plot(n,data(3,:),'Marker','x')
hold on 
plot(n,data(4,:),'.-','LineWidth',1.5,'Color','r')
hold on 
set(gca,'xtick',100:100:1000);
% set(gca,'ytick',0:0.1:1);
hl = legend('MSE-RP x^2_1','MSE-RP x^2_2','MSE-RP x^2_3','x^2');
set(hl,'Box','off','Location','southeast')
title('��-generalized normal with ��=5  m = 10')
xlabel('sample size')
ylabel('Power')

subplot(332)
m10_data = t_data(5:8,:);
data = m10_data;
plot(n,data(1,:),'.-','Color','g','LineWidth',1.5)
axis([100 1000 0 1])
hold on 
plot(n,data(2,:),'Marker','+','Color','b')
hold on 
plot(n,data(3,:),'Marker','x')
hold on 
plot(n,data(4,:),'.-','LineWidth',1.5,'Color','r')
hold on 
set(gca,'xtick',100:100:1000);
% set(gca,'ytick',0:0.1:1);
hl = legend('MSE-RP x^2_1','MSE-RP x^2_2','MSE-RP x^2_3','x^2');
set(hl,'Box','off','Location','southeast')
title('��-generalized normal with ��=5  m = 20')
xlabel('sample size')
ylabel('Power')

subplot(333)
m10_data = t_data(9:12,:);
data = m10_data;
plot(n,data(1,:),'.-','Color','g','LineWidth',1.5)
axis([100 1000 0 1])
hold on 
plot(n,data(2,:),'Marker','+','Color','b')
hold on 
plot(n,data(3,:),'Marker','x')
hold on 
plot(n,data(4,:),'.-','LineWidth',1.5,'Color','r')
hold on 
set(gca,'xtick',100:100:1000);
% set(gca,'ytick',0:0.1:1);
hl = legend('MSE-RP x^2_1','MSE-RP x^2_2','MSE-RP x^2_3','x^2');
set(hl,'Box','off','Location','southeast')
title('��-generalized normal with ��=5  m = 30')
xlabel('sample size')
ylabel('Power')

%===

n = 100:100:1500;
subplot(334)
m10_data = la_data(1:4,:);
data = m10_data;
plot(n,data(1,:),'.-','Color','g','LineWidth',1.5)
axis([50 500 0 1])
hold on 
plot(n,data(2,:),'Marker','+','Color','b')
hold on 
plot(n,data(3,:),'Marker','x')
hold on 
plot(n,data(4,:),'.-','LineWidth',1.5,'Color','r')
hold on 
set(gca,'xtick',50:50:500);
% set(gca,'ytick',0:0.1:1);
hl = legend('MSE-RP x^2_1','MSE-RP x^2_2','MSE-RP x^2_3','x^2');
set(hl,'Box','off','Location','southeast')
title('Kotz(2.5,0.5,2) m = 10')
xlabel('sample size')
ylabel('Power')

subplot(335)
m10_data = la_data(5:8,:);
data = m10_data;
plot(n,data(1,:),'.-','Color','g','LineWidth',1.5)
axis([50 500 0 1])
hold on 
plot(n,data(2,:),'Marker','+','Color','b')
hold on 
plot(n,data(3,:),'Marker','x')
hold on 
plot(n,data(4,:),'.-','LineWidth',1.5,'Color','r')
hold on 
set(gca,'xtick',50:50:500);
% set(gca,'ytick',0:0.1:1);
hl = legend('MSE-RP x^2_1','MSE-RP x^2_2','MSE-RP x^2_3','x^2');
set(hl,'Box','off','Location','southeast')
title('Kotz(2.5,0.5,2) m = 20')
xlabel('sample size')
ylabel('Power')

subplot(336)
m10_data = la_data(9:12,:);
data = m10_data;
plot(n,data(1,:),'.-','Color','g','LineWidth',1.5)
axis([50 500 0 1])
hold on 
plot(n,data(2,:),'Marker','+','Color','b')
hold on 
plot(n,data(3,:),'Marker','x')
hold on 
plot(n,data(4,:),'.-','LineWidth',1.5,'Color','r')
hold on 
set(gca,'xtick',50:50:500);
% set(gca,'ytick',0:0.1:1);
hl = legend('MSE-RP x^2_1','MSE-RP x^2_2','MSE-RP x^2_3','x^2');
set(hl,'Box','off','Location','southeast')
title('Kotz(2.5,0.5,2) m = 30')
xlabel('sample size')
ylabel('Power')
%======

subplot(337)
m10_data = de_data(1:4,:);
data = m10_data;
plot(n,data(1,:),'.-','Color','g','LineWidth',1.5)
axis([50 500 0 1])
hold on 
plot(n,data(2,:),'Marker','+','Color','b')
hold on 
plot(n,data(3,:),'Marker','x')
hold on 
plot(n,data(4,:),'.-','LineWidth',1.5,'Color','r')
hold on 
set(gca,'xtick',50:50:500);
% set(gca,'ytick',0:0.1:1);
hl = legend('MSE-RP x^2_1','MSE-RP x^2_2','MSE-RP x^2_3','x^2');
set(hl,'Box','off','Location','southeast')
title('Kotz(4.5,0.5,4) m = 10')
xlabel('sample size')
ylabel('Power')

subplot(338)
m10_data = de_data(5:8,:);
data = m10_data;
plot(n,data(1,:),'.-','Color','g','LineWidth',1.5)
axis([50 500 0 1])
hold on 
plot(n,data(2,:),'Marker','+','Color','b')
hold on 
plot(n,data(3,:),'Marker','x')
hold on 
plot(n,data(4,:),'.-','LineWidth',1.5,'Color','r')
hold on 
set(gca,'xtick',50:50:500);
% set(gca,'ytick',0:0.1:1);
hl = legend('MSE-RP x^2_1','MSE-RP x^2_2','MSE-RP x^2_3','x^2');
set(hl,'Box','off','Location','southeast')
title('Kotz(4.5,0.5,4) m = 20')
xlabel('sample size')
ylabel('Power')

subplot(339)
m10_data = de_data(9:12,:);
data = m10_data;
plot(n,data(1,:),'.-','Color','g','LineWidth',1.5)
axis([50 500 0 1])
hold on 
plot(n,data(2,:),'Marker','+','Color','b')
hold on 
plot(n,data(3,:),'Marker','x')
hold on 
plot(n,data(4,:),'.-','LineWidth',1.5,'Color','r')
hold on 
set(gca,'xtick',50:50:500);
% set(gca,'ytick',0:0.1:1);
hl = legend('MSE-RP x^2_1','MSE-RP x^2_2','MSE-RP x^2_3','x^2');
set(hl,'Box','off','Location','southeast')
title('Kotz(4.5,0.5,4) m = 30')
xlabel('sample size')
ylabel('Power')


new_data = zeros(10,12);
for i = 1:12
   new_data(:,i) = data(i,:); 
    
end
new_data = roundn(new_data,-4);

%Example
clear;clc;
%n = 1000; %������
random_number = data_3;
n = length(random_number);
k = 15;%k = 10;k = 15; %�����������һ�� 
m = 2*k; %��������������ڷָ�Ķ�����
alpha = 0.05;
normal_RP_data = xlsread('C:\ѧϰ\FYP\Code\һԪ��̬�ֲ�����\Normal.xlsx',1); %��׼��̬�ֲ��Ĵ�����
method_1_x_square = chi2inv(1-alpha,m-3);
method_2_x_square = chi2inv(1-alpha,m-2);
method_3_x_square = chi2inv(1-alpha,m-1);
%Ex1

%random_number = [1,repelem(2,4),repelem(3,10),repelem(4,89),repelem(5,190),repelem(6,212)];
%random_number = [random_number,repelem(7,204),repelem(8,193),repelem(9,79),repelem(10,16),repelem(11,2)]'; %�����е�����
%Ex

miu = mean(random_number);%��ֵ
sigma = std(random_number);%����
normal_RP = normal_RP_data(m,1:m/2); %ѡ���ض�m�µĴ�����
normal_RP_method_1 = miu+sigma.*normal_RP;%�ض��ֲ��Ĵ�����

result = MSE_RP_Method_1(random_number,normal_RP_method_1,n,k,method_1_x_square,miu,sigma,m-3) %���ô����㿨��

dist =  makedist('Normal','mu',miu,'sigma',sigma);
ks_result = kstest(random_number,'cdf',dist,'Alpha',0.05)%ks test
sw_result = swtest(random_number,0.04)%sw test























%================================================================

data_1 = xlsread('.\result\.xlsx',1);
data_2 = xlsread('.\result\N(0,1).xlsx',1);
data_3 = xlsread('.\result\N(0,2).xlsx',1);


n = 50:50:500;
axis([0 5500 0 1])
set(gca,'xtick',50:50:500);

subplot(331)
data = data_1(1:3,:);
plot(n,data(1,:),'.-','Color','g','LineWidth',1.5)
hold on 
plot(n,data(2,:),'.-','LineWidth',1.5,'Color','r')
hold on 
% plot(n,data(3,:),'Marker','x')
% hold on  
hl = legend('RP-x^2','PF-x^2','KS-test');
set(hl,'Box','off','Location','southeast')
title('��-generalized with ��=5 m = 6')
xlabel('sample size')
ylabel('Power')

subplot(332)
data = data_1(4:6,:);
plot(n,data(1,:),'.-','Color','g','LineWidth',1.5)
hold on 
plot(n,data(2,:),'.-','LineWidth',1.5,'Color','r')
hold on 
% plot(n,data(3,:),'Marker','x')
% hold on 
hl = legend('RP-x^2','PF-x^2','KS-test');
set(hl,'Box','off','Location','southeast')
title('��-generalized with ��=5 m = 8')
xlabel('sample size')
ylabel('Power')

subplot(333)
data = data_1(7:9,:);
plot(n,data(1,:),'.-','Color','g','LineWidth',1.5)
hold on 
plot(n,data(2,:),'.-','LineWidth',1.5,'Color','r')
hold on 
% plot(n,data(3,:),'Marker','x')
% hold on 
hl = legend('RP-x^2','PF-x^2','KS-test');
set(hl,'Box','off','Location','southeast')
title('��-generalized with ��=5 m = 10')
xlabel('sample size')
ylabel('Power')

%===
n = 50:50:500;
axis([0 500 0 1])
set(gca,'xtick',50:50:500);

subplot(334)
data = data_2(1:3,:);
plot(n,data(1,:),'.-','Color','g','LineWidth',1.5)
hold on 
plot(n,data(2,:),'.-','LineWidth',1.5,'Color','r')
hold on 
% plot(n,data(3,:),'Marker','x')
% hold on 
hl = legend('RP-x^2','PF-x^2','KS-test');
set(hl,'Box','off','Location','southeast')
title('N(0,1) m = 6')
xlabel('sample size')
ylabel('Power')

subplot(335)
data = data_2(4:6,:);
plot(n,data(1,:),'.-','Color','g','LineWidth',1.5)
hold on 
plot(n,data(2,:),'.-','LineWidth',1.5,'Color','r')
hold on 
% plot(n,data(3,:),'Marker','x')
% hold on 
hl = legend('RP-x^2','PF-x^2','KS-test');
set(hl,'Box','off','Location','southeast')
title('N(0,1) m = 8')
xlabel('sample size')
ylabel('Power')

subplot(336)
data = data_2(7:9,:);
plot(n,data(1,:),'.-','Color','g','LineWidth',1.5)
hold on 
plot(n,data(2,:),'.-','LineWidth',1.5,'Color','r')
hold on 
% plot(n,data(3,:),'Marker','x')
% hold on 
hl = legend('RP-x^2','PF-x^2','KS-test');
set(hl,'Box','off','Location','southeast')
title('N(0,1) m = 10')
xlabel('sample size')
ylabel('Power')
%======
n = 50:50:500;
axis([0 500 0 1])
set(gca,'xtick',50:50:500);

subplot(337)
data = data_3(1:3,:);
plot(n,data(1,:),'.-','Color','g','LineWidth',1.5)
hold on 
plot(n,data(2,:),'.-','LineWidth',1.5,'Color','r')
hold on 
% plot(n,data(3,:),'Marker','x')
% hold on 
hl = legend('RP-x^2','PF-x^2','KS-test');
set(hl,'Box','off','Location','southeast')
title('N(0,2) m = 6')
xlabel('sample size')
ylabel('Power')

subplot(338)
data = data_3(4:6,:);
plot(n,data(1,:),'.-','Color','g','LineWidth',1.5)
hold on 
plot(n,data(2,:),'.-','LineWidth',1.5,'Color','r')
hold on 
% plot(n,data(3,:),'Marker','x')
% hold on 
hl = legend('RP-x^2','PF-x^2','KS-test');
set(hl,'Box','off','Location','southeast')
title('N(0,2) m = 8')
xlabel('sample size')
ylabel('Power')

subplot(339)
data = data_3(7:9,:);
plot(n,data(1,:),'.-','Color','g','LineWidth',1.5)
hold on 
plot(n,data(2,:),'.-','LineWidth',1.5,'Color','r')
hold on 
% plot(n,data(3,:),'Marker','x')
% hold on 
hl = legend('RP-x^2','PF-x^2','KS-test');
set(hl,'Box','off','Location','southeast')
title('N(0,2) m = 10')
xlabel('sample size')
ylabel('Power')



























data = xlsread('.\result\la_laplace.xlsx',1);


n = 100:100:1500;
axis([0 1500 0 1])
set(gca,'xtick',0:300:1500);


data = data_1(1:3,:);
plot(n,data(1,:),'.-','Color','g','LineWidth',1.5)
hold on 
plot(n,data(2,:),'.-','LineWidth',1.5,'Color','r')
hold on 
plot(n,data(3,:),'Marker','x')
hold on  
hl = legend('MSE-RP x^2','x^2','KS-test');
set(hl,'Box','off','Location','southeast')
title('Weibull(3,3.5) m = 6')
xlabel('sample size')
ylabel('Power')













%======================================================================
data_1 = xlsread('.\result\N(0,1).xlsx',1);
data_2 = xlsread('.\result\N(0,2).xlsx',1);



n = 50:50:500;
axis([0 500 0 1])
set(gca,'xtick',0:50:500);

subplot(231)
data = data_1(1:3,:);
plot(n,data(1,:),'.-','Color','g','LineWidth',1.5)
hold on 
plot(n,data(2,:),'.-','LineWidth',1.5,'Color','r')
hold on 
% plot(n,data(3,:),'Marker','x')
% hold on  
hl = legend('RP-x^2','PF-x^2','KS-test');
set(hl,'Box','off','Location','southeast')
title('Cauchy m = 6')
xlabel('sample size')
ylabel('Power')

subplot(232)
data = data_1(4:6,:);
plot(n,data(1,:),'.-','Color','g','LineWidth',1.5)
hold on 
plot(n,data(2,:),'.-','LineWidth',1.5,'Color','r')
hold on 
% plot(n,data(3,:),'Marker','x')
% hold on 
hl = legend('RP-x^2','PF-x^2','KS-test');
set(hl,'Box','off','Location','southeast')
title('Cauchy m = 8')
xlabel('sample size')
ylabel('Power')

subplot(233)
data = data_1(7:9,:);
plot(n,data(1,:),'.-','Color','g','LineWidth',1.5)
hold on 
plot(n,data(2,:),'.-','LineWidth',1.5,'Color','r')
hold on 
% plot(n,data(3,:),'Marker','x')
% hold on 
hl = legend('RP-x^2','PF-x^2','KS-test');
set(hl,'Box','off','Location','southeast')
title('Cauchy m = 10')
xlabel('sample size')
ylabel('Power')

%===


subplot(234)
data = data_2(1:3,:);
plot(n,data(1,:),'.-','Color','g','LineWidth',1.5)
hold on 
plot(n,data(2,:),'.-','LineWidth',1.5,'Color','r')
hold on 
% plot(n,data(3,:),'Marker','x')
% hold on 
hl = legend('RP-x^2','PF-x^2','KS-test');
set(hl,'Box','off','Location','southeast')
title('t(5) m = 6')
xlabel('sample size')
ylabel('Power')

subplot(235)
data = data_2(4:6,:);
plot(n,data(1,:),'.-','Color','g','LineWidth',1.5)
hold on 
plot(n,data(2,:),'.-','LineWidth',1.5,'Color','r')
hold on 
% plot(n,data(3,:),'Marker','x')
% hold on 
hl = legend('RP-x^2','PF-x^2','KS-test');
set(hl,'Box','off','Location','southeast')
title('t(5) m = 8')
xlabel('sample size')
ylabel('Power')

subplot(236)
data = data_2(7:9,:);
plot(n,data(1,:),'.-','Color','g','LineWidth',1.5)
hold on 
plot(n,data(2,:),'.-','LineWidth',1.5,'Color','r')
hold on 
% plot(n,data(3,:),'Marker','x')
% hold on 
hl = legend('RP-x^2','PF-x^2','KS-test');
set(hl,'Box','off','Location','southeast')
title('t(5) m = 10')
xlabel('sample size')
ylabel('Power')




















%========================================================================

data = xlsread('.\result_std.xlsx',1);
data(find(isnan(data)==1)) = 0;

count = 10;
subplot(211)
for i = 1:2
    x = 2005:2020;
    y = data(1+16*(count-1):16+16*(count-1),2+2*(i-1));
    plot(x,y);
    hold on
end
x = 2005:2020;
y = data(1+16*(count-1):16+16*(count-1),6);
plot(x,y)
hl = legend('ר��','������','������');
set(hl,'Box','off','Location','southeast')
title('���ڿ�')
xlabel('���')
ylabel('������')
set(gca,'FontSize',20);
set(gca,'xtick',2005:1:2020);

subplot(212)
for i = 1:2
    x = 2005:2020;
    y = data(1+16*(count-1):16+16*(count-1),2+2*(i-1));
    plot(x,y);
    hold on
end
x = 2005:2020;
y = data(1+16*(count-1):16+16*(count-1),5);
plot(x,y)
hl = legend('ר��','������','������');
set(hl,'Box','off','Location','southeast')
% title('���ڿ�')
xlabel('���')
ylabel('����ʱ��')
set(gca,'FontSize',20);
set(gca,'xtick',2005:1:2020);

%��ְλ��ͼ
newdata = zeros(16,6);
for role = 1:6
    for time = 1:16
        for count = 1:10
            newdata(time,role) = newdata(time,role)+data(time+16*(count-1),role);
        end
    end
end
subplot(211)
for i = [1,3,5]
    x = 2005:2020;
    y = newdata(:,i);
    plot(x,y);
    hold on
end
hl = legend('ר��','������','������');
set(hl,'Box','off','Location','southeast')
title('����ְλ�������仯')
xlabel('���')
ylabel('������')
set(gca,'FontSize',20);
set(gca,'xtick',2005:1:2020);

subplot(212)
for i = [2,4,6]
    x = 2005:2020;
    y = newdata(:,i);
    plot(x,y);
    hold on
end
hl = legend('ר��','������','������');
set(hl,'Box','off','Location','southeast')
% title('���ڿ�')
xlabel('���')
ylabel('����ʱ��')
title('����ְλ����ʱ��仯')
set(gca,'FontSize',20);
set(gca,'xtick',2005:1:2020);


depart_time = zeros(16,10);
for count = 1:9
   for time = 1:16
      depart_time(time,count) = sum(data(16*(count-1)+time,[1,3,5])); 
   end
end
depart_work = zeros(16,10);
for count = 1:9
   for time = 1:16
      depart_work(time,count) = sum(data(16*(count-1)+time,[2,4,6])); 
   end
end

subplot(211)
for count = 1:10
   x = 2005:1:2020;
   y = depart_time(:,count);
   plot(x,y)
   hold on
end
xlabel('���')
ylabel('����ʱ��')
hl = legend('����','���Ǻ���','�ε���','�ǿ�','��ǻ��','�����','Ƥ����','���ٿ�','�񾭿�','���ڿ�');
set(hl,'Box','off','Location','southeast')
set(gca,'FontSize',20);
set(gca,'xtick',2005:1:2020);
subplot(212)
for count = 1:10
   x = 2005:1:2020;
   y = depart_work(:,count);
   plot(x,y)
   hold on 
end
xlabel('���')
ylabel('������')
hl = legend('����','���Ǻ���','�ε���','�ǿ�','��ǻ��','�����','Ƥ����','���ٿ�','�񾭿�','���ڿ�');
set(hl,'Box','off','Location','southeast')
set(gca,'FontSize',20);
set(gca,'xtick',2005:1:2020);












































