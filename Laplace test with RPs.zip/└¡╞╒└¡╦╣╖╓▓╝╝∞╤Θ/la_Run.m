%ע�⣺ֻ�����������������Ĵ��뼴��
%%
%==============================================================
%Simulation for Laplace:
clc;clear;
n  = 30:30:300;N = 100000; %�������
size = length(n);
RP_data = xlsread('.\Laplace.xlsx',1);
result_m10 = zeros(3,size);result_m20 = zeros(3,size);result_m30 = zeros(3,size);
%dist = makedist('tLocationScale','mu',3,'sigma',1,'nu',1);
for i = 1:size
    result_m10(:,i) = Main(n(i),3,N,RP_data); % m = 6
    result_m20(:,i) = Main(n(i),4,N,RP_data);% m = 8
    result_m30(:,i) = Main(n(i),5,N,RP_data);% m = 10
    fprintf('%d\n',i);
end
total_result = [result_m10;result_m20;result_m30];
PLOT(total_result)

%Store the data into a Excel File
xlswrite('.\result\la_error.xlsx',total_result)
%==============================================================
%%

miu = 0;
n = 1000;
m = 10; %10��������
k = 5;
RP = xlsread('.\Laplace.xlsx',1);
RP = RP(m,1:m/2);
BP = zeros(k-1,1);
for i = 1:k-1
   BP(i) = 0.5*(RP(i)+RP(i+1)); 
end
a = zeros(k-1,1);
d = BP-miu;
for i = 1:k-1
   a(i) = miu-d(k-i); 
end
BP = [a;miu;BP];

x = -10:0.01:10;
y = lapdf(x,0,1);
plot(x,y);
hold on 
for i = 1:m-1
    x_p = BP(i);
    line([x_p x_p],[0 lapdf(x_p,0,1)]);
    hold on 
end

clear;clc
format long
alpha = 0.05;
k = 3;
m = 2*k;
RP_data = xlsread('.\Laplace.xlsx',1);
normal_RP = RP_data(m,1:m/2);
random_number = [62,66,78,79,80,84,84,85,85,86,86,87,88,88,89,89,91,91,91,91,92,92,92,92,93,94,94,94,95,95,95,96,96,96,96,96,97,97,97,97,97,97,98,98,98,98,98,98,98,99,99,99,99,99,100,100,100,100,100,101,101,101,101,102,102,102,102,102,102,102,103, 103,103,103,104,104,104,104,104,104,105,105,106,107,107,109,110,111,111,111,114,115,117,122,132,132,137,137,138]';
n = length(random_number);
miu = mean(random_number);
sigma = std(random_number);
b = sum(abs(random_number-miu))/n;
RP = miu+b.*normal_RP; 
x_square = chi2inv(1-alpha,m-3);

f1 = MSE_RP_Method_1(random_number,RP,n,k,x_square,miu,sigma,m)
f2 = Original_Chi_Method(random_number,n,k,x_square,m)










