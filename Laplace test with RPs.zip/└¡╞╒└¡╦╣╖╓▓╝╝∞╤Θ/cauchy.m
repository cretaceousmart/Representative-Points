%this program is devised by Li Run-Ze and revised by Liang Jiajuan

function y=cauchy(n,p)
%This program is used to generate  cauchy distribution with dimension d;
%m=(d+1)/2;
%v=betadist(n,1,d,2*(m-d/2));
%r=sqrt(v./(1-v));
%spdis=sphere(d,n);
%y=spdis.*(r*ones(1,d));
y=pear7dis(n,p,1,(p+1)/2);

